import React from 'react';
import { Mail, MapPin, Clock, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 text-left pt-12 pb-24 md:pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-slate-800">
          {/* Brand & Identity with Official JL Logo */}
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-3">
              <div className="h-10 w-16 sm:w-20 rounded-lg bg-white p-1 flex items-center justify-center shrink-0">
                <img 
                  src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_2.59.47_AM_c5ef15f7.jpeg" 
                  alt="Logo Oficial Jóvenes Libres"
                  className="h-full w-full object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/marca.svg';
                  }}
                />
              </div>
              <div>
                <span className="block text-base font-bold text-white tracking-tight">
                  Jóvenes Libres
                </span>
                <span className="block text-xs text-purple-300">
                  Centro de Estudiantes · Mons. San Fermín Lafitte
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Lista representativa del estudiantado del Instituto Monseñor San Fermín Lafitte. Defendiendo la participación estudiantil, la cultura escolar, el deporte y los derechos de cada curso.
            </p>
            <div className="text-[11px] text-slate-500">
              Marco legal: Ley Nacional de Centros de Estudiantes N° 26.877
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-2.5">
            <span className="block text-xs font-bold text-white uppercase tracking-wider">
              Navegación del Portal
            </span>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button
                  onClick={() => onSelectTab('inicio')}
                  className="hover:text-purple-300 transition-colors"
                >
                  Inicio: ¿Qué pasa esta semana?
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('agenda')}
                  className="hover:text-purple-300 transition-colors"
                >
                  Agenda y Torneos Deportivos
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('proyectos')}
                  className="hover:text-purple-300 transition-colors"
                >
                  Los 10 Proyectos del Centro
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('recursos')}
                  className="hover:text-purple-300 transition-colors"
                >
                  Recursos y Técnicas de Estudio
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('buzon')}
                  className="hover:text-purple-300 transition-colors"
                >
                  Buzón de Sugerencias y Reclamos
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('asistente')}
                  className="hover:text-purple-300 transition-colors"
                >
                  Asistente Estudiantil Lafitte
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('admin')}
                  className="hover:text-purple-300 transition-colors flex items-center gap-1 text-purple-400"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Panel de Administración</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Institutional Hours & Meeting */}
          <div className="md:col-span-4 space-y-3">
            <span className="block text-xs font-bold text-white uppercase tracking-wider">
              Puntos de Contacto y Asambleas
            </span>
            <ul className="space-y-2 text-xs text-slate-400">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                <span>Patio Central y Salón de Actos · Instituto Monseñor San Fermín Lafitte</span>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                <span>Reunión Abierta de Delegados: Viernes 13:30 hs (en punto)</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-purple-400 shrink-0" />
                <span>contacto@joveneslibres-lafitte.edu.ar</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <p>© 2026 Centro de Estudiantes Jóvenes Libres. Conducción Estudiantil.</p>
          <p>Hecho por y para los estudiantes del Monseñor San Fermín Lafitte.</p>
        </div>
      </div>
    </footer>
  );
};
