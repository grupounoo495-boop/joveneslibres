import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Download, 
  Search, 
  CheckCircle2, 
  FileText, 
  X, 
  HelpCircle,
  Lightbulb,
  Check
} from 'lucide-react';
import { StudyResource, INITIAL_RESOURCES } from '../data/portalData';

interface RecursosSectionProps {
  resources?: StudyResource[];
}

export const RecursosSection: React.FC<RecursosSectionProps> = ({
  resources = INITIAL_RESOURCES
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('todas');
  const [selectedCourse, setSelectedCourse] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [previewResource, setPreviewResource] = useState<StudyResource | null>(null);
  const [downloadedId, setDownloadedId] = useState<string | null>(null);

  const categories = [
    { id: 'todas', label: 'Todos los recursos' },
    { id: 'Técnicas de estudio', label: 'Técnicas de estudio' },
    { id: 'Organización', label: 'Organización' },
    { id: 'Guías', label: 'Guías de examen' }
  ];

  const courses = ['Todos', '1° a 3°', '4° a 6°', 'Todos los cursos'];

  const filtered = resources.filter((item) => {
    const matchesCat = selectedCategory === 'todas' || item.category === selectedCategory;
    const matchesCourse = selectedCourse === 'Todos' || item.targetCourse.includes(selectedCourse) || item.targetCourse.includes('Todos');
    const matchesQuery = 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesCourse && matchesQuery;
  });

  const handleDownload = (item: StudyResource) => {
    const textContent = `INSTITUTO MONSEÑOR SAN FERMÍN LAFITTE
CENTRO DE ESTUDIANTES JÓVENES LIBRES
RECURSO ESTUDIANTIL COMPARTIDO

Título: ${item.title}
Categoría: ${item.category}
Curso destinatario: ${item.targetCourse}
Publicado por: ${item.author}

CONSEJOS Y PASOS CLAVE:
${item.contentTips.join('\n')}

DESCRIPCIÓN:
${item.description}

Material pedagógico abierto para estudiantes del Lafitte.`;

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `${item.title.replace(/[\s/]/g, '_')}.txt`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadedId(item.id);
    setTimeout(() => setDownloadedId(null), 3000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-6 text-left"
    >
      {/* Header */}
      <div className="pb-4 border-b border-slate-200">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Recursos de Estudio y Organización
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Guías prácticas, técnicas de estudio activo y herramientas para preparar exámenes en el Lafitte.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 space-y-4">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por técnica, materia o autor..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden text-slate-900"
          />
        </div>

        <div className="flex flex-wrap gap-1.5 pt-1">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
                selectedCategory === c.id
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Resources Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((item) => (
          <motion.div
            key={item.id}
            whileHover={{ y: -2 }}
            className="bg-white rounded-3xl border border-slate-200 p-5 hover:border-purple-300 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-lg border border-purple-200">
                  {item.category}
                </span>
                <span className="text-slate-500 font-medium">
                  Para: {item.targetCourse}
                </span>
              </div>

              <h3 
                onClick={() => setPreviewResource(item)}
                className="text-base font-bold text-slate-900 hover:text-purple-700 transition-colors cursor-pointer mb-2 leading-snug"
              >
                {item.title}
              </h3>

              <p className="text-xs text-slate-600 line-clamp-2 mb-3 leading-relaxed">
                {item.description}
              </p>

              {/* Tips preview */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1 mb-3">
                <div className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                  <span>Puntos clave:</span>
                </div>
                <ul className="text-xs text-slate-600 space-y-0.5 list-disc list-inside">
                  {item.contentTips.slice(0, 2).map((tip, idx) => (
                    <li key={idx} className="truncate">{tip}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs">
              <span className="text-[11px] text-slate-400">
                Publicado por: {item.author}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setPreviewResource(item)}
                  className="px-2.5 py-1.5 text-xs text-slate-600 hover:text-purple-800 font-semibold cursor-pointer"
                >
                  Ver completa
                </button>
                <button
                  onClick={() => handleDownload(item)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                    downloadedId === item.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-purple-700 hover:bg-purple-800 text-white'
                  }`}
                >
                  {downloadedId === item.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      <span>¡Descargado!</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>Descargar</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Preview Modal */}
      <AnimatePresence>
        {previewResource && (
          <div 
            className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-2xs flex items-center justify-center p-4 sm:p-6"
            onClick={() => setPreviewResource(null)}
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-4 text-left border border-slate-100 relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setPreviewResource(null)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>

              <div>
                <span className="text-xs font-bold text-purple-700 uppercase tracking-wider block mb-1">
                  {previewResource.category} · Para {previewResource.targetCourse}
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-slate-900 pr-6">
                  {previewResource.title}
                </h3>
                <span className="text-xs text-slate-500 block mt-0.5">
                  Publicado por {previewResource.author}
                </span>
              </div>

              <div className="bg-purple-50/70 p-4 rounded-2xl border border-purple-100 space-y-2 text-xs">
                <span className="font-bold text-purple-950 block">Guía y Pasos Prácticos:</span>
                <ul className="space-y-1.5 text-slate-700">
                  {previewResource.contentTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-purple-200 text-purple-800 text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-2 flex justify-between items-center">
                <button
                  onClick={() => handleDownload(previewResource)}
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar guía (.txt)</span>
                </button>
                <button
                  onClick={() => setPreviewResource(null)}
                  className="px-3.5 py-2 text-xs text-slate-500 hover:text-slate-800 font-semibold"
                >
                  Cerrar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
