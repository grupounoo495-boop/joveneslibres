export interface AgendaEvent {
  id: string;
  title: string;
  category: 'torneo' | 'radio' | 'asamblea' | 'cultural' | 'taller';
  categoryLabel: string;
  date: string; // ISO date format YYYY-MM-DD
  displayDate: string; // e.g. "Jueves 14 Nov"
  time: string;
  location: string;
  years: string[]; // ['1°', '2°', '3°', '4°', '5°', '6°'] or ['Todos']
  divisions: string[]; // ['A', 'B', 'C', 'Todas']
  description: string;
  responsible: string;
  updatedAt: string;
  isConfirmed: boolean;
  actionLabel?: string;
}

export interface StudentProject {
  id: string;
  number: number;
  name: string;
  category: 'Cultura' | 'Tecnología' | 'Recreación' | 'Formación' | 'Deportes' | 'Bienestar' | 'Participación';
  shortPitch: string;
  summary: string;
  progressPercent: number;
  status: 'en_curso' | 'evaluacion' | 'abierta_convocatoria' | 'activa';
  statusLabel: string;
  currentWork: string;
  nextStep: string;
  howToJoin: string;
  responsible: string;
  openCall: boolean;
  updatedAt: string;
  participantsCount: number;
}

export interface StudyResource {
  id: string;
  title: string;
  category: 'Técnicas de estudio' | 'Organización' | 'Guías' | 'Apuntes';
  targetCourse: string; // '1° a 3°', '4° a 6°', 'Todos', '5° año', etc.
  author: string;
  format: 'Guía práctica' | 'Plantilla' | 'PDF' | 'Ficha';
  description: string;
  contentTips: string[];
}

export interface BuzonTicket {
  id: string;
  code: string;
  topic: string;
  message: string;
  category: 'propuesta' | 'recreo' | 'torneo' | 'infraestructura' | 'otro';
  isAnonymous: boolean;
  studentName?: string;
  studentCourse?: string;
  createdAt: string;
  status: 'pendiente' | 'en_asamblea' | 'derivado_direccion';
  moderatorNotes?: string;
}

export interface AssistantFAQItem {
  id: string;
  question: string;
  answer: string;
  sourceDoc: string;
  article: string;
  isConfirmed: boolean;
  whereItWillBePublished: string;
  tags: string[];
}

// Initial 10 authentic projects from Jovenes Libres
export const INITIAL_PROJECTS: StudentProject[] = [
  {
    id: 'proj-1',
    number: 1,
    name: 'Radio y podcast escolar',
    category: 'Cultura',
    shortPitch: 'Entrevistas, música e historias contadas por estudiantes.',
    summary: 'Espacio de comunicación para producir episodios breves con entrevistas a profes, historias del colegio y música autorizada en los recreos.',
    progressPercent: 65,
    status: 'abierta_convocatoria',
    statusLabel: 'Convocatoria abierta',
    currentWork: 'Definiendo equipos de locución, guion y edición de sonido con los micrófonos adquiridos.',
    nextStep: 'Primer encuentro de producción para armar la grilla del episodio piloto.',
    howToJoin: 'Abierto a todos los cursos. Podés sumarte en locución, operación técnica o redacción de guiones.',
    responsible: 'Secretaría de Cultura y Medios (Jóvenes Libres)',
    openCall: true,
    updatedAt: '10 Nov 2026',
    participantsCount: 18
  },
  {
    id: 'proj-2',
    number: 2,
    name: 'Página web y app estudiantil',
    category: 'Tecnología',
    shortPitch: 'Agenda, recursos y propuestas en un lugar fácil de consultar.',
    summary: 'Portal web abierto y aplicación móvil liviana para que cada estudiante encuentre fechas de torneos, materiales y buzón en dos toques.',
    progressPercent: 95,
    status: 'activa',
    statusLabel: 'Versión activa',
    currentWork: 'Publicación de la versión 1.0 con panel de autogestión para delegados del Lafitte.',
    nextStep: 'Sumar módulo de inscripciones directas a torneos y banco colaborativo de apuntes.',
    howToJoin: 'Podés enviar sugerencias de mejoras directamente por el Buzón del portal.',
    responsible: 'Equipo de Desarrollo y Delegados JL',
    openCall: false,
    updatedAt: '12 Nov 2026',
    participantsCount: 320
  },
  {
    id: 'proj-3',
    number: 3,
    name: 'Cortometrajes estudiantiles',
    category: 'Cultura',
    shortPitch: 'Un espacio para escribir, filmar y mostrar historias propias.',
    summary: 'Taller y muestra audiovisual escolar para explorar guion, cámara, actuación y edición, con muestra final en el Salón de Actos.',
    progressPercent: 40,
    status: 'abierta_convocatoria',
    statusLabel: 'Convocatoria abierta',
    currentWork: 'Recepción de sinopsis e ideas de historias de estudiantes de 1° a 6° año.',
    nextStep: 'Taller introductorio de encuadre y sonido con cámara de celular y micrófonos corbateros.',
    howToJoin: 'Inscribí tu cortometraje individual o en grupo de hasta 5 estudiantes.',
    responsible: 'Comisión Audiovisual',
    openCall: true,
    updatedAt: '08 Nov 2026',
    participantsCount: 14
  },
  {
    id: 'proj-4',
    number: 4,
    name: 'DJ por un recreo',
    category: 'Recreación',
    shortPitch: 'Música en los recreos sugerida y coordinada por cada curso.',
    summary: 'Propuesta para que los cursos participen rotativamente musicalizando los recreos de los viernes con listas cuidadas y respetuosas de la convivencia.',
    progressPercent: 55,
    status: 'en_curso',
    statusLabel: 'En curso',
    currentWork: 'Armado del cronograma de rotación por divisiones y prueba del sistema de sonido del patio.',
    nextStep: 'Presentación formal de las listas de reproducción aprobadas por preceptoría.',
    howToJoin: 'El delegado de tu curso coordina con el Centro para reservar la fecha que le toca a tu división.',
    responsible: 'Secretaría de Recreación',
    openCall: true,
    updatedAt: '09 Nov 2026',
    participantsCount: 42
  },
  {
    id: 'proj-5',
    number: 5,
    name: 'Recreos diferentes',
    category: 'Recreación',
    shortPitch: 'Juegos breves, ping pong y actividades para encontrarnos entre cursos.',
    summary: 'Generación de áreas de juego de mesa (ajedrez, damas, jenga) y mesas de ping pong rotativas en los patios para distenderse en recreos largos.',
    progressPercent: 70,
    status: 'en_curso',
    statusLabel: 'En curso',
    currentWork: 'Distribución de los primeros 4 juegos de ajedrez y 2 mesas de ping pong en el patio cubierto.',
    nextStep: 'Organización del primer torneo interno de ajedrez en recreos de contraturno.',
    howToJoin: 'Los juegos se retiran en la mesita del Centro en cada recreo presentando la credencial.',
    responsible: 'Delegados de Ciclo Básico y Superior',
    openCall: false,
    updatedAt: '07 Nov 2026',
    participantsCount: 65
  },
  {
    id: 'proj-6',
    number: 6,
    name: 'Torneos internos e intercolegiales',
    category: 'Deportes',
    shortPitch: 'Competencias de fútbol, vóley y básquet entre cursos y con otros colegios.',
    summary: 'Encuentros deportivos mixtos en el gimnasio y playón para fomentar el juego limpio, el compañerismo y la integración de todo el Lafitte.',
    progressPercent: 80,
    status: 'abierta_convocatoria',
    statusLabel: 'Convocatoria abierta',
    currentWork: 'Inscripción activa para el Torneo Relámpago de Vóley Mixto de este jueves.',
    nextStep: 'Publicación de los cruces y fixture oficial en la sección Agenda.',
    howToJoin: 'Equipos mixtos de 6 a 8 personas. Anotá a tu división en la mesita del Centro o desde esta web.',
    responsible: 'Secretaría de Deportes Jóvenes Libres',
    openCall: true,
    updatedAt: '11 Nov 2026',
    participantsCount: 96
  },
  {
    id: 'proj-7',
    number: 7,
    name: 'Modelo de Naciones Unidas (ONU)',
    category: 'Formación',
    shortPitch: 'Debate, oratoria y simulación de diplomacia internacional.',
    summary: 'Capacitación en técnicas de debate, redacción de tratados internacionales y representación de delegaciones de países en el modelo anual.',
    progressPercent: 45,
    status: 'evaluacion',
    statusLabel: 'En preparación',
    currentWork: 'Reunión con docentes del área de ciencias sociales para definir reglamento y cupos.',
    nextStep: 'Taller abierto de oratoria y resolución de controversias en el Salón de Actos.',
    howToJoin: 'Podés sumarte como delegado de país o como miembro de la secretaría de prensa del modelo.',
    responsible: 'Comisión de Formación Ciudadana',
    openCall: true,
    updatedAt: '05 Nov 2026',
    participantsCount: 22
  },
  {
    id: 'proj-8',
    number: 8,
    name: 'Charlas con profesionales, cursos y pasantías',
    category: 'Formación',
    shortPitch: 'Encuentros para conocer carreras, oficios y herramientas prácticas.',
    summary: 'Ciclo de charlas con egresados del Lafitte y profesionales de distintas áreas, sumado a gestiones para acercar cursos y primeras experiencias vocacionales.',
    progressPercent: 50,
    status: 'en_curso',
    statusLabel: 'En curso',
    currentWork: 'Relevamiento de intereses vocacionales en cursos de 4°, 5° y 6° año.',
    nextStep: 'Confirmación de fecha para la primera charla de orientación con profesionales de salud y tecnología.',
    howToJoin: 'Votá los temas de charlas que más te interesen en el Buzón de Sugerencias.',
    responsible: 'Mesa de Orientación Estudiantil',
    openCall: false,
    updatedAt: '06 Nov 2026',
    participantsCount: 54
  },
  {
    id: 'proj-9',
    number: 9,
    name: 'Kit de emergencia escolar',
    category: 'Bienestar',
    shortPitch: 'Insumos básicos de primeros auxilios y gestión menstrual en el colegio.',
    summary: 'Disponibilidad de botiquines con curitas, gasas, apósitos y productos de gestión menstrual en preceptorías para resolver imprevistos sin complicaciones.',
    progressPercent: 90,
    status: 'activa',
    statusLabel: 'En funcionamiento',
    currentWork: 'Reposición periódica asegurada cada 15 días con fondos del Centro de Estudiantes.',
    nextStep: 'Auditoría mensual de insumos junto al personal de preceptoría.',
    howToJoin: 'Si detectás que falta algún insumo en la preceptoría de tu curso, avisanos por el Buzón.',
    responsible: 'Secretaría de Bienestar y Salud',
    openCall: false,
    updatedAt: '04 Nov 2026',
    participantsCount: 210
  },
  {
    id: 'proj-10',
    number: 10,
    name: 'Buzón de sugerencias y reclamos',
    category: 'Participación',
    shortPitch: 'Un canal directo para compartir ideas de mejora y reclamos de tu curso.',
    summary: 'Mecanismo abierto para enviar ideas y necesidades sin crear cuenta. Cada mensaje recibe un código de seguimiento y es analizado por los delegados.',
    progressPercent: 100,
    status: 'activa',
    statusLabel: 'Activo en web y patio',
    currentWork: 'Revisión semanal de sugerencias recibidas previa a cada asamblea ordinaria.',
    nextStep: 'Lectura de acuerdos en la asamblea de delegados de los viernes.',
    howToJoin: 'Podés mandar tu propuesta en la pestaña Buzón en cualquier momento.',
    responsible: 'Cuerpo de Delegados Lafitte',
    openCall: true,
    updatedAt: '12 Nov 2026',
    participantsCount: 140
  }
];

// Initial confirmed and pending events in the school calendar
export const INITIAL_AGENDA: AgendaEvent[] = [
  {
    id: 'ev-1',
    title: 'Torneo Relámpago de Vóley Mixto',
    category: 'torneo',
    categoryLabel: 'Torneo Deportivo',
    date: '2026-11-14',
    displayDate: 'Jueves 14 Nov',
    time: '13:30 a 16:30 hs',
    location: 'Playón y Gimnasio Cubierto',
    years: ['3°', '4°', '5°', '6°'],
    divisions: ['Todas'],
    description: 'Partidos cortos de 15 puntos por set entre cursos. Se juega con equipos mixtos de 6 titulares. Traer zapatillas deportivas y botella de agua.',
    responsible: 'Secretaría de Deportes JL',
    updatedAt: '11 Nov 2026',
    isConfirmed: true,
    actionLabel: 'Ver fixture y ubicación'
  },
  {
    id: 'ev-2',
    title: 'Asamblea Abierta de Delegados de Curso',
    category: 'asamblea',
    categoryLabel: 'Asamblea',
    date: '2026-11-15',
    displayDate: 'Viernes 15 Nov',
    time: '13:30 hs (en punto)',
    location: 'Salón de Actos Mons. Lafitte',
    years: ['1°', '2°', '3°', '4°', '5°', '6°'],
    divisions: ['Todas'],
    description: 'Puesta en común semanal de delegados: tratamiento de los mensajes recibidos en el buzón, balance del torneo de vóley y cronograma del podcast.',
    responsible: 'Mesa Directiva Jóvenes Libres',
    updatedAt: '10 Nov 2026',
    isConfirmed: true,
    actionLabel: 'Ver temario de asamblea'
  },
  {
    id: 'ev-3',
    title: 'Recreo con DJ: 4° Año al Control de la Música',
    category: 'radio',
    categoryLabel: 'Recreos & Música',
    date: '2026-11-18',
    displayDate: 'Lunes 18 Nov',
    time: 'Recreo de 10:15 a 10:30 hs',
    location: 'Patio Central de los Naranjos',
    years: ['Todos'],
    divisions: ['Todas'],
    description: 'Estudiantes de 4° año musicalizan el recreo principal con la lista comunitaria autorizada. ¡Acercate a escuchar y sugerir canciones!',
    responsible: 'Delegados de 4° año & Comisión DJ',
    updatedAt: '09 Nov 2026',
    isConfirmed: true,
    actionLabel: 'Sugerir tema musical'
  },
  {
    id: 'ev-4',
    title: 'Primer Encuentro del Laboratorio de Cortos',
    category: 'cultural',
    categoryLabel: 'Audiovisual',
    date: '2026-11-20',
    displayDate: 'Miércoles 20 Nov',
    time: '14:00 hs',
    location: 'Aula 3 (PB - Sector Biblioteca)',
    years: ['1°', '2°', '3°', '4°', '5°', '6°'],
    divisions: ['A', 'B', 'C'],
    description: 'Taller inicial para quienes quieran filmar o actuar en los cortometrajes del Lafitte. No hace falta tener experiencia previa.',
    responsible: 'Comisión Audiovisual JL',
    updatedAt: '08 Nov 2026',
    isConfirmed: true,
    actionLabel: 'Anotarme al taller'
  },
  {
    id: 'ev-5',
    title: 'Taller Introductorio al Modelo ONU',
    category: 'taller',
    categoryLabel: 'Formación',
    date: '2026-11-25',
    displayDate: 'Martes 25 Nov',
    time: '14:30 a 16:00 hs',
    location: 'Salón de Actos',
    years: ['3°', '4°', '5°', '6°'],
    divisions: ['Todas'],
    description: 'Capacitación en reglas de procedimiento diplomático, redacción de discursos y asignación de países para el simulacro.',
    responsible: 'Comisión de Formación',
    updatedAt: '06 Nov 2026',
    isConfirmed: false, // Pending confirmation note!
    actionLabel: 'Consultar estado de confirmación'
  }
];

export const INITIAL_RESOURCES: StudyResource[] = [
  {
    id: 'rec-1',
    title: 'Repaso activo para una prueba: la técnica de las tres preguntas',
    category: 'Técnicas de estudio',
    targetCourse: '1° a 6° año',
    author: 'Comisión Pedagógica Jóvenes Libres',
    format: 'Guía práctica',
    description: 'Método para practicar recordando sin mirar los apuntes. Elegí un tema y escribí 3 preguntas clave antes de abrir el libro.',
    contentTips: [
      '1. Elegí un tema y redactá tres preguntas centrales sin mirar los apuntes.',
      '2. Respondé en una hoja en blanco de memoria.',
      '3. Abrí el apunte, compará qué faltó y corregí lo omitido en otro color.',
      '4. Repetí el ejercicio al día siguiente antes de la clase.'
    ]
  },
  {
    id: 'rec-2',
    title: 'Plantilla para organizar entregas y trabajos prácticos',
    category: 'Organización',
    targetCourse: '1° a 6° año',
    author: 'Cuerpo de Delegados Lafitte',
    format: 'Plantilla',
    description: 'Distribuí una entrega grande en tareas manejables: búsqueda de información, primer borrador, revisión y entrega.',
    contentTips: [
      'Anotá la fecha límite real y fijá la entrega interna 48hs antes.',
      'Día 1-2: Búsqueda de fuentes y selección de textos.',
      'Día 3-4: Redacción del borrador en borrador.',
      'Día 5: Revisión de ortografía, carátula y bibliografía.'
    ]
  },
  {
    id: 'rec-3',
    title: 'Guía de preparación para materias previas y pendientes',
    category: 'Guías',
    targetCourse: '2° a 6° año',
    author: 'Secretaría de Asuntos Académicos JL',
    format: 'Ficha',
    description: 'Pasos para retirar el programa en preceptoría, contactar al profe de la mesa y armar el temario de estudio.',
    contentTips: [
      'Pedí en preceptoría el programa del año exacto en que cursaste la materia.',
      'Asistí a las clases de consulta antes de la mesa evaluadora.',
      'Resolvé modelos de examen de años anteriores que podés consultar en biblioteca.'
    ]
  }
];

export const INITIAL_TICKETS: BuzonTicket[] = [
  {
    id: 'tk-1',
    code: 'JL-2026-4812',
    topic: 'Sumar dispenser de agua caliente para el termo de mate en recreos',
    message: 'Estaría buenísimo tener un dispenser de agua caliente en el patio cubierto para los que nos quedamos en contraturno.',
    category: 'recreo',
    isAnonymous: true,
    createdAt: '10 Nov 2026',
    status: 'en_asamblea',
    moderatorNotes: 'Se presentó en la reunión del viernes 10/11. Se evalúa costo con la concesión del buffet.'
  },
  {
    id: 'tk-2',
    code: 'JL-2026-3904',
    topic: 'Pelotas de básquet para el recreo largo del turno tarde',
    message: 'En el recreo de las 15:30 hs el playón queda vacío porque no hay pelotas de básquet disponibles en preceptoría.',
    category: 'torneo',
    isAnonymous: false,
    studentName: 'Mariano P.',
    studentCourse: '3° A',
    createdAt: '08 Nov 2026',
    status: 'derivado_direccion',
    moderatorNotes: 'El Centro acordó comprar 2 pelotas nuevas que quedarán bajo cuidado de los delegados.'
  }
];

export const INITIAL_FAQS: AssistantFAQItem[] = [
  {
    id: 'faq-1',
    question: '¿Cuándo son las mesas de examen previas de Diciembre?',
    answer: 'Todavía no hay una fecha confirmada oficialmente por el Equipo Directivo. Las fechas de inscripción y el cronograma de comisiones evaluadoras se publicarán en la cartelera digital y en los avisos del portal en cuanto Dirección envíe la resolución.',
    sourceDoc: 'Resolución de Secretaría Lafitte',
    article: 'Pendiente de confirmación ministerial',
    isConfirmed: false,
    whereItWillBePublished: 'Cartelera de Preceptoría y pestaña Agenda del portal',
    tags: ['mesas', 'previas', 'fechas', 'diciembre', 'examenes']
  },
  {
    id: 'faq-2',
    question: '¿Cómo me anoto al Torneo Relámpago de Vóley?',
    answer: 'El torneo se juega el jueves 14 de noviembre de 13:30 a 16:30 hs en el Playón y Gimnasio Cubierto. Para anotarte, hablá con el delegado de tu división o acercate a la mesita del Centro de Estudiantes en los recreos.',
    sourceDoc: 'Reglamento Torneo Jóvenes Libres',
    article: 'Bases Deportivas 2026',
    isConfirmed: true,
    whereItWillBePublished: 'Pestaña Agenda y Proyectos de este portal',
    tags: ['torneo', 'voley', 'inscripcion', 'playon', 'gimnasio']
  },
  {
    id: 'faq-3',
    question: '¿Dónde está el kit de emergencia si me pasa algo en el colegio?',
    answer: 'El kit de emergencia (primeros auxilios, apósitos y toallitas de gestión menstrual) está disponible en la Preceptoría de cada turno y en el botiquín del Centro de Estudiantes.',
    sourceDoc: 'Acuerdo de Bienestar Escolar JL',
    article: 'Acta de Delegados N° 4',
    isConfirmed: true,
    whereItWillBePublished: 'Preceptorías de Ciclo Básico y Superior',
    tags: ['kit', 'emergencia', 'primeros auxilios', 'preceptoria', 'menstrual']
  },
  {
    id: 'faq-4',
    question: '¿Cómo funciona la radio escolar y cómo puedo participar?',
    answer: 'La radio y podcast es un proyecto abierto a estudiantes de todos los cursos. Habrá reuniones de guion y locución en los recreos y contraturno. Podés manifestar tu interés desde la sección Proyectos tocando «Sumarme a la convocatoria».',
    sourceDoc: 'Proyecto Radio Jóvenes Libres',
    article: 'Convocatoria Abierta Noviembre 2026',
    isConfirmed: true,
    whereItWillBePublished: 'Pestaña Proyectos de este portal',
    tags: ['radio', 'podcast', 'locucion', 'musica', 'convocatoria']
  },
  {
    id: 'faq-5',
    question: '¿Qué pasa cuando mando una idea al Buzón?',
    answer: 'Tu mensaje es recibido de forma segura y privada. Llega al panel de los delegados del Centro, se analiza en la reunión semanal previa y se debate en la asamblea de los viernes a las 13:30 hs.',
    sourceDoc: 'Estatuto de Jóvenes Libres',
    article: 'Capítulo III: Participación Estudiantil',
    isConfirmed: true,
    whereItWillBePublished: 'Actas de asamblea y cartelera',
    tags: ['buzon', 'sugerencias', 'reclamos', 'delegados', 'asamblea']
  }
];
