import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  Calendar, 
  Layers, 
  Menu, 
  X, 
  BookOpen, 
  MessageSquare, 
  Sparkles, 
  ShieldCheck, 
  ChevronRight 
} from 'lucide-react';

interface MobileNavProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ currentTab, onSelectTab }) => {
  const [showMoreMenu, setShowMoreMenu] = useState<boolean>(false);

  const primaryTabs = [
    { id: 'inicio', label: 'Inicio', icon: Home },
    { id: 'agenda', label: 'Agenda', icon: Calendar },
    { id: 'proyectos', label: 'Proyectos', icon: Layers },
    { id: 'mas', label: 'Más', icon: Menu },
  ];

  const handleTabClick = (tabId: string) => {
    if (tabId === 'mas') {
      setShowMoreMenu(!showMoreMenu);
    } else {
      setShowMoreMenu(false);
      onSelectTab(tabId);
    }
  };

  const handleSubOption = (tabId: string) => {
    setShowMoreMenu(false);
    onSelectTab(tabId);
  };

  const isMoreActive = ['recursos', 'buzon', 'asistente', 'admin'].includes(currentTab);

  return (
    <>
      {/* "Más" Bottom Sheet Drawer */}
      <AnimatePresence>
        {showMoreMenu && (
          <div className="md:hidden fixed inset-0 z-50 flex flex-col justify-end">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMoreMenu(false)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-2xs"
            />

            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 26, stiffness: 260 }}
              className="relative z-10 bg-white rounded-t-3xl border-t border-purple-100 p-6 pb-24 shadow-2xl space-y-4 text-left max-w-lg mx-auto w-full"
            >
              {/* Grab Handle */}
              <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto" />

              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold uppercase tracking-wider text-purple-900">
                  Opciones y Servicios
                </span>
                <button
                  onClick={() => setShowMoreMenu(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg min-h-[44px] min-w-[44px] flex items-center justify-center"
                  aria-label="Cerrar menú"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => handleSubOption('recursos')}
                  className={`w-full flex items-center justify-between p-3.5 rounded-2xl border transition-all text-left ${
                    currentTab === 'recursos' 
                      ? 'bg-purple-50 border-purple-300 text-purple-950 font-semibold' 
                      : 'bg-slate-50 border-slate-100 text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-sm font-bold block">Recursos Pedagógicos</span>
                      <span className="text-[11px] text-slate-500 block">Guías, técnicas de estudio y organización</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>

                <button
                  onClick={() => handleSubOption('buzon')}
                  className={`w-full flex items-center justify-between p-3.5 rounded-2xl border transition-all text-left ${
                    currentTab === 'buzon' 
                      ? 'bg-purple-50 border-purple-300 text-purple-950 font-semibold' 
                      : 'bg-slate-50 border-slate-100 text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
                      <MessageSquare className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-sm font-bold block">Buzón de Sugerencias</span>
                      <span className="text-[11px] text-slate-500 block">Enviá ideas o reclamos sin crear cuenta</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>

                <button
                  onClick={() => handleSubOption('asistente')}
                  className={`w-full flex items-center justify-between p-3.5 rounded-2xl border transition-all text-left ${
                    currentTab === 'asistente' 
                      ? 'bg-purple-50 border-purple-300 text-purple-950 font-semibold' 
                      : 'bg-slate-50 border-slate-100 text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-sm font-bold block">Asistente Estudiantil</span>
                      <span className="text-[11px] text-slate-500 block">Respuestas normativas con fuentes confirmadas</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>

                <button
                  onClick={() => handleSubOption('admin')}
                  className={`w-full flex items-center justify-between p-3.5 rounded-2xl border transition-all text-left ${
                    currentTab === 'admin' 
                      ? 'bg-purple-100 border-purple-400 text-purple-950 font-semibold' 
                      : 'bg-purple-50/50 border-purple-100 text-purple-900 hover:bg-purple-100/50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-700 text-white flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-sm font-bold block">Panel del Centro</span>
                      <span className="text-[11px] text-purple-700 block">Publicar avisos, fechas y revisar buzón</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-purple-600" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main 4-Tab Mobile Navigation Bar */}
      <nav 
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-purple-100 shadow-lg shadow-purple-950/10 safe-bottom"
        aria-label="Navegación móvil principal"
      >
        <div className="grid grid-cols-4 items-center h-16 max-w-md mx-auto px-2">
          {primaryTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = tab.id === 'mas' ? isMoreActive || showMoreMenu : currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => handleTabClick(tab.id)}
                className={`flex flex-col items-center justify-center min-h-[48px] min-w-[48px] py-1 rounded-xl transition-all ${
                  isActive ? 'text-purple-700 font-semibold' : 'text-slate-500 hover:text-slate-800'
                }`}
                aria-current={isActive ? 'page' : undefined}
              >
                <div className={`relative p-1 rounded-lg transition-transform ${isActive ? 'scale-105' : ''}`}>
                  <Icon className={`w-5 h-5 ${isActive ? 'text-purple-700 stroke-[2.2]' : 'text-slate-500 stroke-[1.8]'}`} />
                  {isActive && (
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-purple-700 rounded-full" />
                  )}
                </div>
                <span className={`text-[11px] mt-0.5 tracking-tight ${isActive ? 'text-purple-900 font-bold' : 'text-slate-600'}`}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
