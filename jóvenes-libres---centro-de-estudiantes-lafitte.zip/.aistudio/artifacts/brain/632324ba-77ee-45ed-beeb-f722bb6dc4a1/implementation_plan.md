# Plan de Implementación: Portal Oficial Jóvenes Libres con Gestión y Animaciones

Rediseño integral del portal web de Jóvenes Libres para el Instituto Monseñor San Fermín Lafitte, incorporando el **logotipo oficial "JL"** (trazo negro con arco violeta dinámico), animaciones fluidas con Motion y una arquitectura centrada en responder en 2 toques las tres preguntas esenciales del estudiante:
1. **¿Qué pasa esta semana?**
2. **¿Qué hay para mi curso?**
3. **¿Cómo puedo participar?**

Incluye un **Panel de Administración para el Centro de Estudiantes** que permite publicar avisos, actualizar estados de proyectos con responsable y fecha, y revisar el buzón sin tocar el código fuente.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Decisiones de diseño y arquitectura confirmadas para esta revisión:
> - **Identidad Visual y Logotipo Oficial**: Se incorpora directamente el asset oficial `/public/assets/aistudio/WhatsApp_Image_2026-11-11_at_2.59.47_AM_c5ef15f7.jpeg` en el encabezado, navegación y tarjetas de marca, manteniendo la paleta violeta (`#7c3aed`), blanco puro y carbón oscuro (`#18181b`).
> - **Navegación Móvil Optimizada**: Se adopta la barra inferior de 4 destinos: **Inicio · Agenda · Proyectos · Más** (donde *Más* agrupa Recursos, Asistente, Estado del Centro y el Panel de Administración). Recursos y Buzón conservan accesos directos destacados en la pantalla de Inicio.
> - **Encontrar el próximo torneo en 2 toques**: Jerarquía clara en Inicio y Agenda para que un estudiante toque "Agenda" o "Torneos" y vea al instante día, horario, lugar (ej. Gimnasio o Playón) y divisiones convocadas.
> - **Proyectos con Convocatorias Reales para Sumarse**: Cada proyecto (Radio y Podcast, Cortometrajes, Recreos & DJ, Torneos, Modelo ONU, Charlas & Cursos) detalla: qué se está haciendo, próximo paso, responsable y botón directo «Sumarme al proyecto».
> - **Panel de Administración Sostenible**: Panel integrado para el equipo del Centro de Estudiantes con:
>   - Publicador de eventos y avisos (con responsable, curso destinatario y fecha de actualización).
>   - Editor de estado de proyectos y apertura de convocatorias.
>   - Bandeja de entrada privada del Buzón de Sugerencias para clasificar mensajes.
>   - Persistencia local inmediata (`localStorage`) para que las altas y ediciones impacten en tiempo real sin requerir despliegues de código.
> - **Asistente Honesto**: Respuestas normativas fundamentadas; si una fecha o dato aún no fue confirmado por Dirección, responderá honestamente: *«Todavía no hay una fecha confirmada. Se publicará en la cartelera digital y en las asambleas de los viernes»*.

---

### 1. Overview & Core Concept

- **Misión del Portal**: Ser la herramienta cotidiana del estudiante del Lafitte para no perderse ninguna actividad, acceder al material de su curso y ser protagonista en los proyectos del colegio.
- **Público**: Estudiantes de 1° a 6° año, delegados de división y el equipo directivo/docente del Instituto Monseñor San Fermín Lafitte.
- **Valor Central**: Autonomía y transparencia. El estudiante obtiene respuestas concretas en segundos; el Centro de Estudiantes puede mantener la información fresca todas las semanas desde su propio panel.

---

### 2. User Experience & Visual Design

#### A. Flujo de Pantallas
1. **Inicio ("¿Qué pasa hoy y esta semana?")**:
   - Encabezado con logotipo oficial "JL" y botón rápido al Buzón.
   - Banner de *Próxima Actividad Inmediata* (día, hora, lugar exacto y año/división a quién va dirigida).
   - Selector rápido: *«¿Qué hay para mi curso?»* (chips 1° a 6° para filtrar de inmediato).
   - Bloque *«¿Cómo participar?»* con las convocatorias abiertas de Radio, Torneos y ONU.
   - Accesos directos a Recursos Pedagógicos y Buzón de Sugerencias.
2. **Agenda Escolar & Torneos**:
   - Filtros combinados por Año (1° a 6°) y División (A, B, C).
   - Pestañas rápidas: Todos · Torneos Deportivos · Asambleas · Talleres.
   - Conservación del filtro al abrir el detalle y volver.
   - Exportación de evento a calendario personal (`.ics`).
3. **Proyectos del Centro**:
   - Tarjetas de los 6 proyectos clave con avance porcentual, responsable, próximo hito y formulario/botón modal para anotarse.
4. **Recursos de Estudio**:
   - Apuntes, técnicas de estudio y modelos de examen indicando autor, materia y curso específico.
5. **Buzón Estudiantil**:
   - Envío ágil sin registro previo, ticket copiable (`JL-2026-XXXX`) y explicación de quién revisa los mensajes.
6. **Menú "Más" & Panel de Administración**:
   - Pestaña para acceder a Recursos, Asistente Normativo y al Panel de Gestión para delegados.
   - Panel protegido con clave simple para que los delegados gestionen avisos y buzón en vivo.

#### B. Sistema de Animaciones (`motion`)
- **Transiciones entre pestañas**: Desplazamiento sutil con `AnimatePresence` (`opacity: 0 -> 1`, `y: 8 -> 0` en 180ms).
- **Tarjetas interactivas**: Micro-elevación (`whileHover: { y: -2 }`, `whileTap: { scale: 0.99 }`).
- **Estados de carga y éxito**: Animaciones de confirmación con checkmark dinámico y spinners contenidos.
- **Accesibilidad**: Compatibilidad total con `prefers-reduced-motion` mediante reseteo automático de duraciones.

---

### 3. Key Product Decisions & Trade-Offs

- **Panel de Administración en el Frontend (Client-side persistente)**:
  - *Decisión*: Proveer un panel de administración directamente integrado en la aplicación web, sincronizado con almacenamiento local (`localStorage`) y con datos semilla reales preconfigurados.
  - *Razón*: Permite que el equipo del Centro actualice inmediatamente eventos, proyectos y avisos desde cualquier teléfono o computadora sin depender de servidores externos ni romper la demo.
- **Navegación de 4 ítems en Mobile (Inicio · Agenda · Proyectos · Más)**:
  - *Decisión*: Reducir de 6 a 4 los botones inferiores para celulares, agrupando Recursos, Asistente y Administración bajo "Más".
  - *Razón*: Sigue la recomendación explícita del usuario y maximiza el área táctil de cada botón en pantallas de 360 a 430 px.
- **Logotipo Oficial**:
  - *Decisión*: Emplear el archivo real `/public/assets/aistudio/WhatsApp_Image_2026-11-11_at_2.59.47_AM_c5ef15f7.jpeg` preservando la nitidez y contraste sobre fondos claros y oscuros.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        App.tsx (Root State)                           │
│   • Estado activo (inicio | agenda | proyectos | recursos | buzon)     │
│   • Logotipo oficial "JL" (/public/assets/aistudio/...)               │
│   • Almacenamiento local para Agenda, Proyectos y Tickets del Buzón   │
└──────────────────────────────────┬─────────────────────────────────────┘
                                   │
              AnimatePresence (Transición fluida de pestañas)
                                   │
      ┌────────────────────────────┼────────────────────────────┐
      ▼                            ▼                            ▼
┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│   HomeSection    │     │  AgendaSection   │     │ ProyectosSection │
│ • Próxima fecha  │     │ • Torneos y acts │     │ • 6 Proyectos    │
│ • "¿Qué hay para │     │ • Filtro año/div │     │ • Convocatorias  │
│    mi curso?"    │     │ • Detalle modal  │     │ • "¿Cómo sumarme?│
│ • Convocatorias  │     │ • 2 toques máx.  │     │ • Hitos y fechas │
└──────────────────┘     └──────────────────┘     └──────────────────┘
      ▲                            ▲                            ▲
      │                            │                            │
┌─────┴────────────┐     ┌─────────┴────────┐     ┌─────────────┴────┐
│   RecursosView   │     │    BuzonView     │     │    AdminPanel    │
│ • Guías & apunte │     │ • Sin cuenta     │     │ • Publicar aviso │
│ • Curso/autor    │     │ • Ticket copiable│     │ • Crear evento   │
│ • Descarga .txt  │     │ • Panel privado  │     │ • Revisar buzón  │
└──────────────────┘     └──────────────────┘     └──────────────────┘
```

- **Estructura de Datos Centralizada (`src/data/portalData.ts`)**:
  - `AgendaEvent`: `id`, `title`, `category` (torneo, asamblea, taller, radio), `date`, `time`, `location`, `years`, `divisions`, `description`, `responsible`, `updatedAt`.
  - `Project`: `id`, `name`, `status`, `progress`, `summary`, `nextStep`, `howToJoin`, `responsible`, `openCall` (boolean), `updatedAt`.
  - `Resource`: `id`, `title`, `course`, `subject`, `author`, `format`, `description`.
  - `BuzonTicket`: `id`, `code`, `subject`, `message`, `category`, `createdAt`, `status` (pendiente, revisado, asamblea).
