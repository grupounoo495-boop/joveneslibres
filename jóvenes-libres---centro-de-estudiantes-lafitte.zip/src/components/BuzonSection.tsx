import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Copy, 
  Check, 
  ShieldCheck, 
  Clock, 
  Users,
  MessageSquare
} from 'lucide-react';
import { BuzonTicket } from '../data/portalData';

interface BuzonSectionProps {
  onNewTicketCreated?: (ticket: BuzonTicket) => void;
}

export const BuzonSection: React.FC<BuzonSectionProps> = ({ onNewTicketCreated }) => {
  const [topic, setTopic] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [category, setCategory] = useState<'propuesta' | 'recreo' | 'torneo' | 'infraestructura' | 'otro'>('propuesta');
  const [isAnonymous, setIsAnonymous] = useState<boolean>(true);
  const [studentName, setStudentName] = useState<string>('');
  const [studentCourse, setStudentCourse] = useState<string>('4°');

  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [createdTicket, setCreatedTicket] = useState<BuzonTicket | null>(null);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!topic.trim() || topic.trim().length < 5) {
      setStatus('error');
      setErrorMessage('Por favor escribí un asunto claro de al menos 5 caracteres.');
      return;
    }

    if (!message.trim() || message.trim().length < 15) {
      setStatus('error');
      setErrorMessage('Contanos tu idea con un poco más de detalle (mínimo 15 caracteres). Tu texto sigue a salvo en el formulario.');
      return;
    }

    if (!isAnonymous && !studentName.trim()) {
      setStatus('error');
      setErrorMessage('Ingresá tu nombre o activá el interruptor de envío anónimo.');
      return;
    }

    setStatus('submitting');
    setErrorMessage('');

    setTimeout(() => {
      const randomCode = Math.floor(1000 + Math.random() * 9000);
      const newTicket: BuzonTicket = {
        id: `tk-${Date.now()}`,
        code: `JL-2026-${randomCode}`,
        topic: topic.trim(),
        message: message.trim(),
        category,
        isAnonymous,
        studentName: isAnonymous ? undefined : studentName.trim(),
        studentCourse: isAnonymous ? undefined : studentCourse,
        createdAt: new Date().toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' }),
        status: 'pendiente'
      };

      setCreatedTicket(newTicket);
      setStatus('success');

      if (onNewTicketCreated) {
        onNewTicketCreated(newTicket);
      }
    }, 800);
  };

  const handleCopyCode = () => {
    if (createdTicket) {
      navigator.clipboard.writeText(createdTicket.code);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2500);
    }
  };

  const handleResetForm = () => {
    setTopic('');
    setMessage('');
    setStudentName('');
    setStatus('idle');
    setCreatedTicket(null);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-8 max-w-4xl mx-auto text-left"
    >
      {/* Header */}
      <div className="pb-4 border-b border-slate-200">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Buzón de Sugerencias y Reclamos
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Compartí tus ideas, pedidos para tu aula o propuestas para el colegio sin crear ninguna cuenta.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Form / Success Card */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 sm:p-7 shadow-2xs">
          {status === 'success' && createdTicket ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-5"
            >
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <CheckCircle2 className="w-7 h-7" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-slate-900">
                  ¡Idea registrada con éxito!
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Tu propuesta ya ingresó a la bandeja de moderación del Centro de Estudiantes.
                </p>
              </div>

              {/* Ticket Card */}
              <div className="bg-purple-50 rounded-2xl p-4 border border-purple-200 space-y-2">
                <span className="text-xs text-purple-800 font-bold uppercase tracking-wider block">
                  Código de seguimiento oficial:
                </span>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-mono font-extrabold text-purple-950 tracking-wider">
                    {createdTicket.code}
                  </span>
                  <button
                    onClick={handleCopyCode}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-white text-purple-800 hover:bg-purple-100 rounded-lg text-xs font-semibold border border-purple-200 transition-colors cursor-pointer"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>¡Copiado!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copiar</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Summary */}
              <div className="text-xs text-slate-600 space-y-1.5 bg-slate-50 p-4 rounded-xl border border-slate-100">
                <div>
                  <span className="font-bold text-slate-800">Tema: </span>
                  <span>{createdTicket.topic}</span>
                </div>
                <div>
                  <span className="font-bold text-slate-800">Modalidad: </span>
                  <span>{createdTicket.isAnonymous ? 'Anónimo' : `${createdTicket.studentName} (${createdTicket.studentCourse})`}</span>
                </div>
              </div>

              <button
                onClick={handleResetForm}
                className="w-full py-2.5 px-4 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                Enviar otra propuesta
              </button>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Category picker */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Área de tu propuesta:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'propuesta', label: 'Propuesta General' },
                    { id: 'recreo', label: 'Recreos y Música' },
                    { id: 'torneo', label: 'Torneos y Deporte' },
                    { id: 'infraestructura', label: 'Aulas y Patio' },
                    { id: 'otro', label: 'Otro tema' }
                  ].map((c) => (
                    <button
                      type="button"
                      key={c.id}
                      onClick={() => setCategory(c.id as any)}
                      className={`py-2 px-2.5 text-xs font-bold rounded-xl transition-all ${
                        category === c.id
                          ? 'bg-purple-700 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Topic */}
              <div className="space-y-1">
                <label htmlFor="topic-input" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  ¿De qué se trata en una frase?
                </label>
                <input
                  id="topic-input"
                  type="text"
                  placeholder="Ej: Faltan bancos en el patio / Propuesta de torneo de ping pong"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden text-slate-900"
                  required
                />
              </div>

              {/* Message */}
              <div className="space-y-1">
                <label htmlFor="buzon-message" className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Detalles de tu idea o reclamo:
                </label>
                <textarea
                  id="buzon-message"
                  rows={4}
                  placeholder="Explicá qué cambiarías, qué aula o espacio involucra y cuál sería la mejor solución..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden text-slate-900"
                  required
                />
                <span className="block text-[11px] text-slate-400">
                  Mínimo 15 caracteres. Tu texto queda a salvo si ocurre cualquier error.
                </span>
              </div>

              {/* Anonymous switch */}
              <div className="p-3.5 rounded-2xl bg-purple-50/70 border border-purple-100 flex items-center justify-between">
                <div>
                  <span className="block text-xs font-bold text-slate-900">
                    Envío 100% anónimo
                  </span>
                  <span className="block text-[11px] text-slate-500">
                    No pedimos nombre, correo ni cuenta.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAnonymous(!isAnonymous)}
                  className={`w-11 h-6 rounded-full transition-colors relative focus-visible:ring-2 focus-visible:ring-purple-600 ${
                    isAnonymous ? 'bg-purple-700' : 'bg-slate-300'
                  }`}
                  role="switch"
                  aria-checked={isAnonymous}
                >
                  <span
                    className={`block w-4 h-4 bg-white rounded-full transition-transform absolute top-1 left-1 ${
                      isAnonymous ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* If not anonymous */}
              {!isAnonymous && (
                <div className="grid grid-cols-2 gap-3 pt-1 border-t border-slate-100 animate-in fade-in">
                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-slate-700">Tu Nombre:</label>
                    <input
                      type="text"
                      placeholder="Ej: Julián R."
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-slate-700">Tu Curso:</label>
                    <select
                      value={studentCourse}
                      onChange={(e) => setStudentCourse(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl"
                    >
                      {['1°', '2°', '3°', '4°', '5°', '6°'].map((c) => (
                        <option key={c} value={c}>{c} año</option>
                      ))}
                    </select>
                  </div>
                </div>
              )}

              {/* Error Alert */}
              {status === 'error' && errorMessage && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={status === 'submitting'}
                className="w-full py-3 px-4 bg-purple-700 hover:bg-purple-800 disabled:opacity-70 text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                {status === 'submitting' ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Enviando al equipo...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Enviar al Centro de Estudiantes</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>

        {/* Right Column: Process & Transparency */}
        <div className="lg:col-span-5 space-y-5 text-left">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-purple-700" />
              <span>¿Quién revisa los envíos?</span>
            </h3>

            <p className="text-xs text-slate-600 leading-relaxed">
              Los mensajes llegan de forma privada a los delegados moderadores de Jóvenes Libres. Se protegen tus datos y se analizan con seriedad.
            </p>

            <div className="space-y-3 text-xs text-slate-700">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-800 font-bold flex items-center justify-center shrink-0 text-xs">
                  1
                </span>
                <div>
                  <strong className="text-slate-900 block">Revisión en el Panel:</strong>
                  Una persona del equipo designada confirma los datos de la sugerencia.
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-800 font-bold flex items-center justify-center shrink-0 text-xs">
                  2
                </span>
                <div>
                  <strong className="text-slate-900 block">Asamblea de los Viernes:</strong>
                  Se debate a las 13:30 hs con delegados de todos los cursos.
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-800 font-bold flex items-center justify-center shrink-0 text-xs">
                  3
                </span>
                <div>
                  <strong className="text-slate-900 block">Gestión con Dirección:</strong>
                  Si requiere permiso o compra de insumos, se presenta en el libro de actas.
                </div>
              </div>
            </div>
          </div>

          <div className="bg-purple-50/70 rounded-3xl border border-purple-200 p-5 text-xs text-purple-950 space-y-2">
            <div className="flex items-center gap-2 font-bold">
              <Clock className="w-4 h-4 text-purple-700" />
              <span>Atención Presencial de Delegados</span>
            </div>
            <p className="text-slate-700 leading-relaxed">
              También podés charlar en persona con los delegados en la mesita del Centro en los recreos principales (10:15 hs y 15:30 hs) en el Patio Central.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
