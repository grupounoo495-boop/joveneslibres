import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Search, 
  ExternalLink, 
  Copy, 
  Check, 
  Send, 
  FileText, 
  ShieldCheck, 
  AlertCircle,
  X,
  Clock
} from 'lucide-react';
import { INITIAL_FAQS, AssistantFAQItem } from '../data/portalData';

export const AsistenteSection: React.FC = () => {
  const [faqs] = useState<AssistantFAQItem[]>(INITIAL_FAQS);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [customQuestion, setCustomQuestion] = useState<string>('');
  const [customAnswer, setCustomAnswer] = useState<AssistantFAQItem | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [selectedFaqSource, setSelectedFaqSource] = useState<AssistantFAQItem | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = faqs.filter((f) => {
    const q = searchQuery.toLowerCase();
    return (
      f.question.toLowerCase().includes(q) ||
      f.answer.toLowerCase().includes(q) ||
      f.tags.some(t => t.toLowerCase().includes(q))
    );
  });

  const handleAsk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customQuestion.trim()) return;

    setIsProcessing(true);
    setTimeout(() => {
      const q = customQuestion.toLowerCase();
      let match = faqs.find(f => 
        f.tags.some(t => q.includes(t)) ||
        f.question.toLowerCase().includes(q)
      );

      if (!match) {
        if (q.includes('mesa') || q.includes('previa') || q.includes('examen') || q.includes('fecha')) {
          match = faqs[0]; // Not confirmed date rule
        } else if (q.includes('torneo') || q.includes('voley') || q.includes('futbol')) {
          match = faqs[1];
        } else if (q.includes('kit') || q.includes('toallita') || q.includes('primeros auxilios') || q.includes('emergencia')) {
          match = faqs[2];
        } else if (q.includes('radio') || q.includes('podcast') || q.includes('musica')) {
          match = faqs[3];
        } else {
          match = faqs[4];
        }
      }

      setCustomAnswer(match);
      setIsProcessing(false);
    }, 500);
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-6 max-w-4xl mx-auto text-left"
    >
      {/* Header */}
      <div className="pb-4 border-b border-slate-200">
        <div className="flex items-center gap-2 text-xs font-bold text-purple-700 uppercase tracking-wider mb-1">
          <Sparkles className="w-4 h-4" />
          <span>Asistente de Consulta Escolar</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Asistente Estudiantil Lafitte
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Respuestas fundamentadas a partir de documentos confirmados del colegio. Si una fecha aún no fue fijada, te explicamos dónde y cuándo se anunciará.
        </p>
      </div>

      {/* Ask Question Card */}
      <div className="bg-white rounded-3xl border border-purple-200/90 p-5 sm:p-6 shadow-2xs space-y-4">
        <form onSubmit={handleAsk} className="space-y-3">
          <label htmlFor="faq-input" className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
            ¿Qué querés consultar sobre la vida escolar?
          </label>
          <div className="flex gap-2">
            <input
              id="faq-input"
              type="text"
              placeholder="Ej: ¿Cuándo son las mesas de previas? o ¿Cómo me anoto al torneo?"
              value={customQuestion}
              onChange={(e) => setCustomQuestion(e.target.value)}
              className="flex-1 px-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden text-slate-900"
            />
            <button
              type="submit"
              disabled={isProcessing || !customQuestion.trim()}
              className="px-4 py-2.5 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 cursor-pointer"
            >
              <span>{isProcessing ? 'Buscando...' : 'Preguntar'}</span>
            </button>
          </div>
        </form>

        {/* Suggestion Chips */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs pt-1">
          <span className="text-slate-400 font-medium">Preguntas de ejemplo:</span>
          {[
            'Fechas de previas',
            'Torneo de vóley',
            'Kit de emergencia',
            'Radio escolar',
            'Buzón de ideas'
          ].map((chip) => (
            <button
              key={chip}
              type="button"
              onClick={() => {
                setCustomQuestion(chip);
                setSearchQuery(chip);
              }}
              className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-800 rounded-lg text-xs font-semibold transition-colors"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Custom Answer Card with Honest Pending Date Rule */}
        {customAnswer && (
          <motion.div 
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
              customAnswer.isConfirmed 
                ? 'bg-purple-50/90 border-purple-200' 
                : 'bg-amber-50/80 border-amber-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold flex items-center gap-1.5 ${
                customAnswer.isConfirmed ? 'text-purple-900' : 'text-amber-900'
              }`}>
                {customAnswer.isConfirmed ? (
                  <>
                    <ShieldCheck className="w-4 h-4 text-purple-700" />
                    <span>Respuesta confirmada</span>
                  </>
                ) : (
                  <>
                    <Clock className="w-4 h-4 text-amber-700" />
                    <span>Fecha no confirmada aún por Dirección</span>
                  </>
                )}
              </span>

              <button
                onClick={() => setSelectedFaqSource(customAnswer)}
                className="text-xs font-semibold text-purple-700 hover:text-purple-900 underline flex items-center gap-1"
              >
                <span>Ver fuente</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-sm text-slate-800 leading-relaxed font-medium">
              {customAnswer.answer}
            </p>

            <div className="pt-2 border-t border-purple-200/60 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2">
              <span className="font-semibold">
                📍 Dónde se publicará: {customAnswer.whereItWillBePublished}
              </span>
              <button
                onClick={() => handleCopy('custom', customAnswer.answer)}
                className="text-purple-700 hover:text-purple-950 font-semibold flex items-center gap-1"
              >
                {copiedId === 'custom' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>¡Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        )}
      </div>

      {/* FAQs List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            Consultas Frecuentes
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            {filtered.length} respuestas verificadas
          </span>
        </div>

        <div className="space-y-3">
          {filtered.map((faq) => (
            <div
              key={faq.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 hover:border-purple-300 transition-all space-y-2.5 text-xs sm:text-sm"
            >
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug">
                  {faq.question}
                </h3>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded shrink-0 ${
                  faq.isConfirmed ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'
                }`}>
                  {faq.isConfirmed ? 'Confirmado' : 'Pendiente'}
                </span>
              </div>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {faq.answer}
              </p>

              <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                <button
                  onClick={() => setSelectedFaqSource(faq)}
                  className="text-purple-700 hover:text-purple-900 font-semibold flex items-center gap-1 bg-purple-50 px-2.5 py-1 rounded-lg border border-purple-200 transition-colors"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Fuente: {faq.sourceDoc}</span>
                  <ExternalLink className="w-3 h-3 ml-0.5" />
                </button>

                <span className="text-[11px] text-slate-400">
                  Canal de publicación: {faq.whereItWillBePublished}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Source Modal */}
      <AnimatePresence>
        {selectedFaqSource && (
          <div 
            className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-2xs flex items-center justify-center p-4 sm:p-6"
            onClick={() => setSelectedFaqSource(null)}
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-4 text-left border border-slate-100 relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedFaqSource(null)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full"
                aria-label="Cerrar fuente"
              >
                <X className="w-5 h-5" />
              </button>

              <div>
                <span className="text-xs font-bold text-purple-700 uppercase tracking-wider block mb-1">
                  Documento de Referencia
                </span>
                <h3 className="text-lg font-bold text-slate-900 pr-6">
                  {selectedFaqSource.sourceDoc}
                </h3>
                <span className="text-xs font-semibold text-purple-700 block mt-0.5">
                  {selectedFaqSource.article}
                </span>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs text-slate-700 leading-relaxed space-y-2">
                <p>
                  <strong>Estado de la información:</strong> {selectedFaqSource.isConfirmed ? 'Datos plenamente confirmados por las partes correspondientes.' : 'Fecha pendiente de resolución oficial por autoridades escolares.'}
                </p>
                <p>
                  <strong>Dónde se anunciará:</strong> {selectedFaqSource.whereItWillBePublished}
                </p>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setSelectedFaqSource(null)}
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold"
                >
                  Entendido
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
