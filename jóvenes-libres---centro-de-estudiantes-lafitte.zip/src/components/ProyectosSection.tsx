import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Layers, 
  Users, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  X, 
  Send, 
  Sparkles,
  Search,
  Radio,
  Film,
  Trophy,
  Globe,
  GraduationCap
} from 'lucide-react';
import { StudentProject } from '../data/portalData';

interface ProyectosSectionProps {
  projects: StudentProject[];
  selectedProject: StudentProject | null;
  onSelectProject: (proj: StudentProject | null) => void;
  onJoinProject: (projectId: string, studentData: { name: string; course: string; role: string }) => void;
}

export const ProyectosSection: React.FC<ProyectosSectionProps> = ({
  projects,
  selectedProject,
  onSelectProject,
  onJoinProject
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('todas');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Join modal state
  const [joinModalProject, setJoinModalProject] = useState<StudentProject | null>(null);
  const [joinName, setJoinName] = useState<string>('');
  const [joinCourse, setJoinCourse] = useState<string>('4°');
  const [joinRole, setJoinRole] = useState<string>('');
  const [joinSuccess, setJoinSuccess] = useState<boolean>(false);

  const categories = [
    { id: 'todas', label: 'Todos los proyectos' },
    { id: 'Cultura', label: 'Cultura & Radio' },
    { id: 'Recreación', label: 'Recreos & Música' },
    { id: 'Deportes', label: 'Torneos' },
    { id: 'Formación', label: 'Modelo ONU & Charlas' },
    { id: 'Bienestar', label: 'Bienestar' }
  ];

  const filteredProjects = projects.filter((p) => {
    const matchesCat = activeCategory === 'todas' || p.category === activeCategory;
    const matchesSearch = 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.shortPitch.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.currentWork.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinModalProject || !joinName.trim()) return;

    onJoinProject(joinModalProject.id, {
      name: joinName.trim(),
      course: joinCourse,
      role: joinRole.trim() || 'Participante general'
    });

    setJoinSuccess(true);
    setTimeout(() => {
      setJoinSuccess(false);
      setJoinModalProject(null);
      setJoinName('');
      setJoinRole('');
    }, 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6 text-left"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Proyectos del Centro de Estudiantes
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Conocé el avance de cada propuesta de Jóvenes Libres, el próximo paso y cómo sumarte a las convocatorias.
          </p>
        </div>

        <div className="text-xs bg-purple-50 text-purple-900 font-bold px-3 py-1.5 rounded-xl border border-purple-200 flex items-center gap-1.5 self-start sm:self-center">
          <Sparkles className="w-4 h-4 text-purple-700" />
          <span>10 iniciativas impulsadas por el Lafitte</span>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 space-y-4">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar proyectos por nombre (ej. radio, cortos, torneos, ONU, DJ)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden text-slate-900"
          />
        </div>

        <div className="flex flex-wrap gap-1.5 pt-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
                activeCategory === cat.id
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredProjects.map((proj) => (
          <motion.div
            key={proj.id}
            whileHover={{ y: -2 }}
            className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 hover:border-purple-300 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              {/* Header */}
              <div className="flex items-center justify-between gap-2 text-xs mb-3">
                <span className="font-bold text-purple-800 bg-purple-50 px-2.5 py-0.5 rounded-lg border border-purple-200">
                  {proj.number}. {proj.category}
                </span>

                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                  proj.status === 'activa'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                    : proj.status === 'abierta_convocatoria'
                    ? 'bg-purple-50 text-purple-800 border border-purple-200'
                    : 'bg-amber-50 text-amber-800 border border-amber-200'
                }`}>
                  {proj.statusLabel}
                </span>
              </div>

              {/* Title & Short Pitch */}
              <h3 
                onClick={() => onSelectProject(proj)}
                className="text-lg font-bold text-slate-900 hover:text-purple-700 transition-colors cursor-pointer mb-1 leading-snug"
              >
                {proj.name}
              </h3>
              <p className="text-xs text-purple-900/80 font-medium mb-3">
                {proj.shortPitch}
              </p>

              {/* Progress Bar */}
              <div className="space-y-1 mb-4">
                <div className="flex justify-between text-[11px] text-slate-500 font-medium">
                  <span>Avance de la propuesta</span>
                  <span className="font-bold text-purple-900">{proj.progressPercent}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div 
                    className="bg-purple-700 h-2 rounded-full transition-all duration-500" 
                    style={{ width: `${proj.progressPercent}%` }}
                  />
                </div>
              </div>

              {/* Qué se está haciendo */}
              <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-100 space-y-2 mb-4 text-xs">
                <div>
                  <span className="font-bold text-slate-800 block mb-0.5">
                    ¿Qué se está haciendo hoy?
                  </span>
                  <p className="text-slate-600 leading-relaxed">
                    {proj.currentWork}
                  </p>
                </div>
                <div className="pt-2 border-t border-slate-200/60">
                  <span className="font-bold text-purple-900 flex items-center gap-1 mb-0.5">
                    <Clock className="w-3.5 h-3.5 text-purple-600" />
                    <span>Próximo paso:</span>
                  </span>
                  <p className="text-slate-700">
                    {proj.nextStep}
                  </p>
                </div>
              </div>
            </div>

            {/* Actions & Responsible footer */}
            <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="text-[11px] text-slate-400">
                <span>Responsable: {proj.responsible}</span>
                <span className="block text-slate-400">Actualizado: {proj.updatedAt}</span>
              </div>

              <div className="flex items-center gap-2">
                {proj.openCall ? (
                  <button
                    onClick={() => setJoinModalProject(proj)}
                    className="px-3.5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>Sumarme</span>
                  </button>
                ) : (
                  <button
                    onClick={() => onSelectProject(proj)}
                    className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Ver detalles
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Join Project Modal */}
      <AnimatePresence>
        {joinModalProject && (
          <div 
            className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-2xs flex items-center justify-center p-4 sm:p-6"
            onClick={() => setJoinModalProject(null)}
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 text-left border border-slate-100 relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setJoinModalProject(null)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full"
                aria-label="Cerrar modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div>
                <span className="text-xs font-bold text-purple-700 uppercase tracking-wider block mb-1">
                  Convocatoria de Estudiantes
                </span>
                <h3 className="text-xl font-bold text-slate-900 pr-6">
                  Sumate a {joinModalProject.name}
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  {joinModalProject.howToJoin}
                </p>
              </div>

              {joinSuccess ? (
                <div className="py-6 text-center space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                  <h4 className="text-base font-bold text-slate-900">¡Te anotaste con éxito!</h4>
                  <p className="text-xs text-slate-500">
                    Los delegados coordinadores te contactarán en el próximo recreo para sumarte al grupo.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleJoinSubmit} className="space-y-3.5">
                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-slate-700">
                      Tu Nombre y Apellido:
                    </label>
                    <input
                      type="text"
                      placeholder="Ej: Martina Fernández"
                      value={joinName}
                      onChange={(e) => setJoinName(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-xs font-semibold text-slate-700">
                        Año escolar:
                      </label>
                      <select
                        value={joinCourse}
                        onChange={(e) => setJoinCourse(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                      >
                        {['1°', '2°', '3°', '4°', '5°', '6°'].map((c) => (
                          <option key={c} value={c}>{c} año</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-xs font-semibold text-slate-700">
                        ¿Cómo te gustaría colaborar?
                      </label>
                      <input
                        type="text"
                        placeholder="Ej: locución, jugador, cámara..."
                        value={joinRole}
                        onChange={(e) => setJoinRole(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-2.5 px-4 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Confirmar inscripción al proyecto</span>
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
