import React from 'react';
import { motion } from 'motion/react';
import { MessageSquarePlus, Shield, Sparkles } from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenBuzon: () => void;
  onOpenAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  currentTab, 
  onSelectTab, 
  onOpenBuzon,
  onOpenAdmin
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-purple-100/90 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark with Official JL Logo */}
        <button 
          onClick={() => onSelectTab('inicio')}
          className="flex items-center gap-3 text-left group focus-visible:ring-2 focus-visible:ring-purple-600 rounded-lg p-1 -ml-1 transition-transform active:scale-[0.99]"
        >
          <div className="h-10 w-16 sm:w-20 rounded-lg bg-white border border-slate-200/90 flex items-center justify-center p-1 shadow-2xs overflow-hidden shrink-0">
            <img 
              src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_2.59.47_AM_c5ef15f7.jpeg" 
              alt="Logo Oficial Jóvenes Libres"
              className="h-full w-full object-contain"
              onError={(e) => {
                // SVG fallback
                (e.target as HTMLImageElement).src = '/marca.svg';
              }}
            />
          </div>
          <div>
            <span className="block text-base font-bold tracking-tight text-slate-900 group-hover:text-purple-700 transition-colors">
              Jóvenes Libres
            </span>
            <span className="block text-[11px] font-medium text-purple-700/80 tracking-normal">
              Centro de Estudiantes · Mons. Lafitte
            </span>
          </div>
        </button>

        {/* Zone 2: Desktop Navigation Links (Single Line) */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2 text-sm font-medium text-slate-600" aria-label="Navegación principal">
          <button
            onClick={() => onSelectTab('inicio')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              currentTab === 'inicio' 
                ? 'text-purple-900 bg-purple-50 font-semibold' 
                : 'hover:text-purple-700 hover:bg-slate-50'
            }`}
          >
            Inicio
          </button>
          <button
            onClick={() => onSelectTab('agenda')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              currentTab === 'agenda' 
                ? 'text-purple-900 bg-purple-50 font-semibold' 
                : 'hover:text-purple-700 hover:bg-slate-50'
            }`}
          >
            Agenda
          </button>
          <button
            onClick={() => onSelectTab('proyectos')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              currentTab === 'proyectos' 
                ? 'text-purple-900 bg-purple-50 font-semibold' 
                : 'hover:text-purple-700 hover:bg-slate-50'
            }`}
          >
            Proyectos
          </button>
          <button
            onClick={() => onSelectTab('recursos')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              currentTab === 'recursos' 
                ? 'text-purple-900 bg-purple-50 font-semibold' 
                : 'hover:text-purple-700 hover:bg-slate-50'
            }`}
          >
            Recursos
          </button>
          <button
            onClick={() => onSelectTab('asistente')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              currentTab === 'asistente' 
                ? 'text-purple-900 bg-purple-50 font-semibold' 
                : 'hover:text-purple-700 hover:bg-slate-50'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span>Asistente</span>
          </button>
          <button
            onClick={onOpenAdmin}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1 text-slate-500 hover:text-purple-800 ${
              currentTab === 'admin' 
                ? 'text-purple-900 bg-purple-100 font-semibold' 
                : 'hover:bg-slate-100'
            }`}
            title="Panel de administración y publicaciones para el equipo"
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Panel</span>
          </button>
        </nav>

        {/* Zone 3: Primary CTA */}
        <div className="flex items-center gap-3 shrink-0">
          <motion.button
            whileHover={{ y: -1 }}
            whileTap={{ scale: 0.98 }}
            onClick={onOpenBuzon}
            className="flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold text-white bg-purple-700 hover:bg-purple-800 rounded-xl shadow-xs transition-colors whitespace-nowrap cursor-pointer"
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span>Buzón</span>
          </motion.button>
        </div>
      </div>
    </header>
  );
};
