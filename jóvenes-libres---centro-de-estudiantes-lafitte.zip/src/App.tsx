/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Header } from './components/Header';
import { MobileNav } from './components/MobileNav';
import { HomeSection } from './components/HomeSection';
import { AgendaSection } from './components/AgendaSection';
import { ProyectosSection } from './components/ProyectosSection';
import { RecursosSection } from './components/RecursosSection';
import { BuzonSection } from './components/BuzonSection';
import { AsistenteSection } from './components/AsistenteSection';
import { AdminPanel } from './components/AdminPanel';
import { Footer } from './components/Footer';
import { 
  INITIAL_AGENDA, 
  INITIAL_PROJECTS, 
  INITIAL_TICKETS, 
  AgendaEvent, 
  StudentProject, 
  BuzonTicket 
} from './data/portalData';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('inicio');

  // Agenda events with localStorage persistence for admin edits
  const [agenda, setAgenda] = useState<AgendaEvent[]>(() => {
    try {
      const saved = localStorage.getItem('jl_agenda_events');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_AGENDA;
  });

  const [selectedAgendaEvent, setSelectedAgendaEvent] = useState<AgendaEvent | null>(null);

  // Projects with localStorage persistence
  const [projects, setProjects] = useState<StudentProject[]>(() => {
    try {
      const saved = localStorage.getItem('jl_projects');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_PROJECTS;
  });

  const [selectedProject, setSelectedProject] = useState<StudentProject | null>(null);

  // Buzón tickets with localStorage persistence
  const [tickets, setTickets] = useState<BuzonTicket[]>(() => {
    try {
      const saved = localStorage.getItem('jl_buzon_tickets');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_TICKETS;
  });

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('jl_agenda_events', JSON.stringify(agenda));
    } catch {}
  }, [agenda]);

  useEffect(() => {
    try {
      localStorage.setItem('jl_projects', JSON.stringify(projects));
    } catch {}
  }, [projects]);

  useEffect(() => {
    try {
      localStorage.setItem('jl_buzon_tickets', JSON.stringify(tickets));
    } catch {}
  }, [tickets]);

  // Tab switching with smooth scroll
  const handleSelectTab = (tab: string) => {
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Admin Event Handlers
  const handleAddEvent = (newEventData: Omit<AgendaEvent, 'id'>) => {
    const newEvent: AgendaEvent = {
      ...newEventData,
      id: `ev-${Date.now()}`
    };
    setAgenda(prev => [newEvent, ...prev]);
  };

  const handleUpdateEvent = (updated: AgendaEvent) => {
    setAgenda(prev => prev.map(ev => ev.id === updated.id ? updated : ev));
    if (selectedAgendaEvent?.id === updated.id) {
      setSelectedAgendaEvent(updated);
    }
  };

  const handleDeleteEvent = (id: string) => {
    setAgenda(prev => prev.filter(ev => ev.id !== id));
    if (selectedAgendaEvent?.id === id) {
      setSelectedAgendaEvent(null);
    }
  };

  // Admin Project Handler
  const handleUpdateProject = (updated: StudentProject) => {
    setProjects(prev => prev.map(p => p.id === updated.id ? updated : p));
    if (selectedProject?.id === updated.id) {
      setSelectedProject(updated);
    }
  };

  // Join Project Handler
  const handleJoinProject = (projectId: string, studentData: { name: string; course: string; role: string }) => {
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        return {
          ...p,
          participantsCount: p.participantsCount + 1
        };
      }
      return p;
    }));
  };

  // Buzon Ticket creation
  const handleNewTicket = (ticket: BuzonTicket) => {
    setTickets(prev => [ticket, ...prev]);
  };

  // Admin Ticket Status Handler
  const handleUpdateTicketStatus = (ticketId: string, status: 'pendiente' | 'en_asamblea' | 'derivado_direccion', note?: string) => {
    setTickets(prev => prev.map(tk => {
      if (tk.id === ticketId) {
        return {
          ...tk,
          status,
          moderatorNotes: note || tk.moderatorNotes
        };
      }
      return tk;
    }));
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#fcfcff] text-slate-900 selection:bg-purple-200 selection:text-purple-900">
      {/* Accessible Skip Link */}
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:px-4 focus:py-2 focus:bg-purple-700 focus:text-white focus:rounded-lg focus:shadow-lg text-xs font-semibold"
      >
        Saltar al contenido principal
      </a>

      {/* Top Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        onOpenBuzon={() => handleSelectTab('buzon')}
        onOpenAdmin={() => handleSelectTab('admin')}
      />

      {/* Main Content Area */}
      <main 
        id="main-content" 
        className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 md:py-10 pb-24 md:pb-12"
      >
        <AnimatePresence mode="wait">
          {currentTab === 'inicio' && (
            <motion.div
              key="inicio"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              <HomeSection
                agenda={agenda}
                projects={projects}
                onNavigate={(tab) => handleSelectTab(tab)}
                onOpenEventDetail={(ev) => {
                  setSelectedAgendaEvent(ev);
                  setCurrentTab('agenda');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                onOpenProjectDetail={(proj) => {
                  setSelectedProject(proj);
                  setCurrentTab('proyectos');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              />
            </motion.div>
          )}

          {currentTab === 'agenda' && (
            <motion.div
              key="agenda"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              <AgendaSection
                agenda={agenda}
                selectedItem={selectedAgendaEvent}
                onSelectItem={setSelectedAgendaEvent}
              />
            </motion.div>
          )}

          {currentTab === 'proyectos' && (
            <motion.div
              key="proyectos"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              <ProyectosSection
                projects={projects}
                selectedProject={selectedProject}
                onSelectProject={setSelectedProject}
                onJoinProject={handleJoinProject}
              />
            </motion.div>
          )}

          {currentTab === 'recursos' && (
            <motion.div
              key="recursos"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              <RecursosSection />
            </motion.div>
          )}

          {currentTab === 'buzon' && (
            <motion.div
              key="buzon"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              <BuzonSection onNewTicketCreated={handleNewTicket} />
            </motion.div>
          )}

          {currentTab === 'asistente' && (
            <motion.div
              key="asistente"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              <AsistenteSection />
            </motion.div>
          )}

          {currentTab === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
            >
              <AdminPanel
                agenda={agenda}
                projects={projects}
                tickets={tickets}
                onAddEvent={handleAddEvent}
                onUpdateEvent={handleUpdateEvent}
                onDeleteEvent={handleDeleteEvent}
                onUpdateProject={handleUpdateProject}
                onUpdateTicketStatus={handleUpdateTicketStatus}
                onClose={() => handleSelectTab('inicio')}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Institutional Footer */}
      <Footer onSelectTab={handleSelectTab} />

      {/* Mobile 4-Tab Bottom Navigation Bar */}
      <MobileNav
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
      />
    </div>
  );
}
