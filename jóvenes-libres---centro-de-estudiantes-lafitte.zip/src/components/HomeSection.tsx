import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Calendar, 
  MapPin, 
  Clock, 
  ArrowRight, 
  BookOpen, 
  MessageSquare, 
  Trophy, 
  Radio, 
  Film, 
  Globe, 
  Sparkles, 
  Users, 
  CheckCircle2, 
  ChevronRight,
  Filter
} from 'lucide-react';
import { AgendaEvent, StudentProject } from '../data/portalData';

interface HomeSectionProps {
  agenda: AgendaEvent[];
  projects: StudentProject[];
  onNavigate: (tab: string, filterCourse?: string) => void;
  onOpenEventDetail: (event: AgendaEvent) => void;
  onOpenProjectDetail: (project: StudentProject) => void;
}

export const HomeSection: React.FC<HomeSectionProps> = ({
  agenda,
  projects,
  onNavigate,
  onOpenEventDetail,
  onOpenProjectDetail,
}) => {
  const [selectedCourseFilter, setSelectedCourseFilter] = useState<string>('Todos');

  // Next immediate activity
  const nextActivity = agenda[0] || null;

  // Next tournament (to test "find next tournament and see where it is played in 2 taps")
  const nextTournament = agenda.find(e => e.category === 'torneo') || agenda[0];

  // Open call projects
  const openCallProjects = projects.filter(p => p.openCall).slice(0, 3);

  // Filter activities for the selected course
  const activitiesForCourse = agenda.filter(item => {
    if (selectedCourseFilter === 'Todos') return true;
    return item.years.includes(selectedCourseFilter) || item.years.includes('Todos');
  });

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-8 sm:space-y-10 text-left"
    >
      {/* Editorial Hero Banner with Official JL Identity */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-purple-950 to-indigo-950 text-white p-6 sm:p-8 lg:p-10 shadow-xl shadow-purple-950/15">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-8 space-y-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-200">
              <span className="w-2 h-2 rounded-full bg-purple-400" />
              <span>Centro de Estudiantes · Instituto Monseñor San Fermín Lafitte</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-tight">
              ¿Qué pasa en el Lafitte esta semana?
            </h1>

            <p className="text-sm sm:text-base text-purple-100/90 max-w-xl leading-relaxed">
              Encontrá el próximo torneo, enterate de las actividades de tu curso y sumate a la radio, los cortos y las asambleas del colegio.
            </p>

            {/* Quick 3-Question Bar */}
            <div className="pt-2 flex flex-wrap gap-2 text-xs">
              <button
                onClick={() => onNavigate('agenda')}
                className="px-3 py-2 bg-white/10 hover:bg-white/20 active:bg-white/25 rounded-xl font-medium text-white transition-colors border border-white/10 flex items-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5 text-purple-300" />
                <span>¿Qué pasa esta semana?</span>
              </button>
              <button
                onClick={() => {
                  const targetEl = document.getElementById('seccion-mi-curso');
                  targetEl?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-3 py-2 bg-white/10 hover:bg-white/20 active:bg-white/25 rounded-xl font-medium text-white transition-colors border border-white/10 flex items-center gap-1.5"
              >
                <Filter className="w-3.5 h-3.5 text-purple-300" />
                <span>¿Qué hay para mi curso?</span>
              </button>
              <button
                onClick={() => {
                  const targetEl = document.getElementById('seccion-participar');
                  targetEl?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-3 py-2 bg-purple-600 hover:bg-purple-500 active:bg-purple-700 rounded-xl font-semibold text-white transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <Users className="w-3.5 h-3.5" />
                <span>¿Cómo puedo participar?</span>
              </button>
            </div>
          </div>

          {/* Logo Showcase Card */}
          <div className="lg:col-span-4 flex justify-center lg:justify-end">
            <div className="bg-white/95 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-purple-200/50 shadow-lg text-center max-w-[260px] w-full">
              <div className="h-16 w-full flex items-center justify-center mb-2">
                <img 
                  src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_2.59.47_AM_c5ef15f7.jpeg" 
                  alt="JL Jóvenes Libres Logo" 
                  className="max-h-full max-w-full object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/marca.svg';
                  }}
                />
              </div>
              <span className="text-xs font-bold text-slate-900 block">Jóvenes Libres</span>
              <span className="text-[11px] text-purple-800 font-medium block">Lista 1 · Conducción Estudiantil</span>
            </div>
          </div>
        </div>
      </section>

      {/* QUESTION 1: "¿Qué pasa esta semana?": Próxima Actividad Destacada */}
      {nextActivity && (
        <section aria-labelledby="proxima-actividad-heading" className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 id="proxima-actividad-heading" className="text-xs font-bold uppercase tracking-wider text-purple-900 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-purple-700" />
              <span>Próxima Actividad Confirmada</span>
            </h2>
            <button
              onClick={() => onNavigate('agenda')}
              className="text-xs font-semibold text-purple-700 hover:text-purple-900 flex items-center gap-1"
            >
              <span>Ver agenda completa</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <motion.div 
            whileHover={{ y: -2 }}
            onClick={() => onOpenEventDetail(nextActivity)}
            className="bg-white rounded-3xl border border-purple-200/90 p-5 sm:p-6 hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs mb-2">
              <div className="flex items-center gap-2">
                <span className="font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-lg border border-purple-200">
                  {nextActivity.categoryLabel}
                </span>
                <span className="text-slate-500">
                  Para: {nextActivity.years.join(', ')} (División {nextActivity.divisions.join(', ')})
                </span>
              </div>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                Confirmada
              </span>
            </div>

            <h3 className="text-lg sm:text-xl font-bold text-slate-900 group-hover:text-purple-700 transition-colors mb-2">
              {nextActivity.title}
            </h3>

            <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 mb-4 leading-relaxed">
              {nextActivity.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-3 border-t border-slate-100 text-xs">
              <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                <Calendar className="w-4 h-4 text-purple-600" />
                <span>{nextActivity.displayDate}</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-600">
                <Clock className="w-4 h-4 text-purple-600" />
                <span>{nextActivity.time}</span>
              </div>
              <div className="flex items-center gap-1.5 font-semibold text-purple-950">
                <MapPin className="w-4 h-4 text-purple-600" />
                <span className="truncate">{nextActivity.location}</span>
              </div>
            </div>
          </motion.div>
        </section>
      )}

      {/* QUICK TOURNAMENT TEST: "Encontrar el próximo torneo y ver dónde se juega en 2 toques" */}
      {nextTournament && (
        <section className="bg-purple-50/70 border border-purple-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 bg-purple-700 text-white rounded-xl shrink-0 mt-0.5 sm:mt-0 shadow-xs">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-purple-900 mb-0.5">
                <span>PRÓXIMO TORNEO DEPORTIVO</span>
                <span aria-hidden="true">·</span>
                <span className="text-purple-700">{nextTournament.displayDate}</span>
              </div>
              <p className="text-sm text-slate-900 font-bold">
                {nextTournament.title}
              </p>
              <div className="flex items-center gap-2 text-xs text-slate-600 mt-1">
                <span className="flex items-center gap-1 font-semibold text-purple-900">
                  <MapPin className="w-3.5 h-3.5 text-purple-700" />
                  {nextTournament.location}
                </span>
                <span>·</span>
                <span>{nextTournament.time}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onOpenEventDetail(nextTournament)}
            className="self-end sm:self-center px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold whitespace-nowrap transition-colors flex items-center gap-1.5 shrink-0 shadow-xs cursor-pointer"
          >
            <span>Ver detalles y fixture</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </section>
      )}

      {/* QUESTION 2: "¿Qué hay para mi curso?" */}
      <section id="seccion-mi-curso" className="space-y-4 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-200">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              ¿Qué hay para mi curso?
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Elegí tu año para ver qué actividades, torneos y avisos aplican a tu división.
            </p>
          </div>

          {/* Course Selector Buttons */}
          <div className="flex flex-wrap gap-1.5">
            {['Todos', '1°', '2°', '3°', '4°', '5°', '6°'].map((course) => (
              <button
                key={course}
                onClick={() => setSelectedCourseFilter(course)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
                  selectedCourseFilter === course
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {course === 'Todos' ? 'Todos los cursos' : `${course} año`}
              </button>
            ))}
          </div>
        </div>

        {activitiesForCourse.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center text-xs text-slate-500">
            No hay actividades exclusivas programadas para {selectedCourseFilter} año en este momento.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {activitiesForCourse.slice(0, 4).map((item) => (
              <motion.div
                key={item.id}
                whileHover={{ y: -1 }}
                onClick={() => onOpenEventDetail(item)}
                className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-purple-300 transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                    <span className="font-semibold text-purple-700">{item.categoryLabel}</span>
                    <span>Cursos: {item.years.join(', ')}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 mb-1 leading-snug">
                    {item.title}
                  </h4>
                  <p className="text-xs text-slate-600 line-clamp-2 mb-3">
                    {item.description}
                  </p>
                </div>
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="font-medium text-slate-700">
                    {item.displayDate} · {item.time}
                  </span>
                  <span className="font-semibold text-purple-700">
                    {item.location}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      {/* QUESTION 3: "¿Cómo puedo participar?" Convocatorias abiertas */}
      <section id="seccion-participar" className="space-y-4 pt-2">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              ¿Cómo puedo participar?
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Convocatorias abiertas de Jóvenes Libres para sumarte ahora.
            </p>
          </div>
          <button
            onClick={() => onNavigate('proyectos')}
            className="text-xs font-semibold text-purple-700 hover:text-purple-900 flex items-center gap-1"
          >
            <span>Ver los 10 proyectos</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {openCallProjects.map((proj) => (
            <motion.div
              key={proj.id}
              whileHover={{ y: -2 }}
              onClick={() => onOpenProjectDetail(proj)}
              className="bg-white rounded-2xl border border-slate-200 p-5 hover:border-purple-300 hover:shadow-sm transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-[11px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
                    {proj.category}
                  </span>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                    Convocatoria
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 mb-1.5 leading-snug">
                  {proj.name}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-3 mb-3 leading-relaxed">
                  {proj.howToJoin}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400">
                  {proj.responsible}
                </span>
                <span className="font-semibold text-purple-700 flex items-center gap-0.5">
                  <span>Sumarme</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Direct Shortcuts to Recursos and Buzón */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
        <motion.div
          whileHover={{ y: -1 }}
          onClick={() => onNavigate('recursos')}
          className="bg-gradient-to-br from-white to-purple-50/40 rounded-2xl border border-slate-200 p-5 hover:border-purple-300 transition-all cursor-pointer flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Recursos de Estudio</h4>
              <p className="text-xs text-slate-500">Técnicas de repaso activo y plantillas para entregas.</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-purple-600 shrink-0" />
        </motion.div>

        <motion.div
          whileHover={{ y: -1 }}
          onClick={() => onNavigate('buzon')}
          className="bg-gradient-to-br from-white to-purple-50/40 rounded-2xl border border-slate-200 p-5 hover:border-purple-300 transition-all cursor-pointer flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-purple-700 text-white flex items-center justify-center shrink-0">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Buzón de Sugerencias</h4>
              <p className="text-xs text-slate-500">Compartí tu propuesta sin crear cuenta y con ticket.</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-purple-600 shrink-0" />
        </motion.div>
      </section>
    </motion.div>
  );
};
