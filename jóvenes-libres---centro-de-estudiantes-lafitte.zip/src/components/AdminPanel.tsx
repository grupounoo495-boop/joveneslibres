import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, 
  CalendarPlus, 
  Layers, 
  Inbox, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  AlertCircle, 
  Clock, 
  Save, 
  X,
  MapPin,
  CheckCircle2,
  Users
} from 'lucide-react';
import { AgendaEvent, StudentProject, BuzonTicket } from '../data/portalData';

interface AdminPanelProps {
  agenda: AgendaEvent[];
  projects: StudentProject[];
  tickets: BuzonTicket[];
  onAddEvent: (event: Omit<AgendaEvent, 'id'>) => void;
  onUpdateEvent: (event: AgendaEvent) => void;
  onDeleteEvent: (id: string) => void;
  onUpdateProject: (project: StudentProject) => void;
  onUpdateTicketStatus: (ticketId: string, status: 'pendiente' | 'en_asamblea' | 'derivado_direccion', note?: string) => void;
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  agenda,
  projects,
  tickets,
  onAddEvent,
  onUpdateEvent,
  onDeleteEvent,
  onUpdateProject,
  onUpdateTicketStatus,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'agenda' | 'proyectos' | 'buzon'>('agenda');
  
  // Event form state
  const [showNewEventForm, setShowNewEventForm] = useState<boolean>(false);
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  const [eventTitle, setEventTitle] = useState<string>('');
  const [eventCategory, setEventCategory] = useState<'torneo' | 'radio' | 'asamblea' | 'cultural' | 'taller'>('torneo');
  const [eventCategoryLabel, setEventCategoryLabel] = useState<string>('Torneo Deportivo');
  const [eventDate, setEventDate] = useState<string>('2026-11-20');
  const [eventDisplayDate, setEventDisplayDate] = useState<string>('Miércoles 20 Nov');
  const [eventTime, setEventTime] = useState<string>('13:30 hs');
  const [eventLocation, setEventLocation] = useState<string>('Playón y Gimnasio');
  const [eventYears, setEventYears] = useState<string>('Todos');
  const [eventDivisions, setEventDivisions] = useState<string>('Todas');
  const [eventDesc, setEventDesc] = useState<string>('');
  const [eventResponsible, setEventResponsible] = useState<string>('Secretaría de Deportes JL');
  const [eventConfirmed, setEventConfirmed] = useState<boolean>(true);
  const [feedbackMsg, setFeedbackMsg] = useState<string>('');

  // Project editing
  const [editingProject, setEditingProject] = useState<StudentProject | null>(null);

  const handleSaveEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventTitle.trim() || !eventLocation.trim()) return;

    const formattedYears = eventYears === 'Todos' ? ['Todos'] : eventYears.split(',').map(s => s.trim());
    const formattedDivisions = eventDivisions === 'Todas' ? ['Todas'] : eventDivisions.split(',').map(s => s.trim());

    if (editingEventId) {
      const existing = agenda.find(ev => ev.id === editingEventId);
      if (existing) {
        onUpdateEvent({
          ...existing,
          title: eventTitle.trim(),
          category: eventCategory,
          categoryLabel: eventCategoryLabel,
          date: eventDate,
          displayDate: eventDisplayDate,
          time: eventTime,
          location: eventLocation.trim(),
          years: formattedYears,
          divisions: formattedDivisions,
          description: eventDesc.trim(),
          responsible: eventResponsible.trim(),
          isConfirmed: eventConfirmed,
          updatedAt: new Date().toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' })
        });
        setFeedbackMsg('¡Actividad actualizada exitosamente en Inicio y Agenda!');
      }
    } else {
      onAddEvent({
        title: eventTitle.trim(),
        category: eventCategory,
        categoryLabel: eventCategoryLabel,
        date: eventDate,
        displayDate: eventDisplayDate,
        time: eventTime,
        location: eventLocation.trim(),
        years: formattedYears,
        divisions: formattedDivisions,
        description: eventDesc.trim(),
        responsible: eventResponsible.trim(),
        isConfirmed: eventConfirmed,
        updatedAt: new Date().toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' })
      });
      setFeedbackMsg('¡Nueva actividad publicada en vivo!');
    }

    setTimeout(() => setFeedbackMsg(''), 3000);
    resetEventForm();
  };

  const startEditEvent = (ev: AgendaEvent) => {
    setEditingEventId(ev.id);
    setEventTitle(ev.title);
    setEventCategory(ev.category);
    setEventCategoryLabel(ev.categoryLabel);
    setEventDate(ev.date);
    setEventDisplayDate(ev.displayDate);
    setEventTime(ev.time);
    setEventLocation(ev.location);
    setEventYears(ev.years.join(', '));
    setEventDivisions(ev.divisions.join(', '));
    setEventDesc(ev.description);
    setEventResponsible(ev.responsible);
    setEventConfirmed(ev.isConfirmed);
    setShowNewEventForm(true);
  };

  const resetEventForm = () => {
    setEditingEventId(null);
    setEventTitle('');
    setEventDesc('');
    setShowNewEventForm(false);
  };

  const handleSaveProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject) return;
    onUpdateProject({
      ...editingProject,
      updatedAt: new Date().toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' })
    });
    setFeedbackMsg(`¡Avance de "${editingProject.name}" actualizado!`);
    setTimeout(() => setFeedbackMsg(''), 3000);
    setEditingProject(null);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-6 text-left"
    >
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-purple-900 to-indigo-950 text-white p-6 rounded-3xl shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-200">
            <ShieldCheck className="w-4 h-4 text-purple-400" />
            <span>Panel de Administración · Jóvenes Libres</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white">
            Gestión y Sostenibilidad del Portal
          </h1>
          <p className="text-xs text-purple-200/90 max-w-xl">
            Publicá avisos, actualizá el avance de los 10 proyectos y gestioná los mensajes del buzón sin tocar una sola línea de código.
          </p>
        </div>

        <button
          onClick={onClose}
          className="px-3.5 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold transition-colors self-end sm:self-center"
        >
          Volver a la vista pública
        </button>
      </div>

      {feedbackMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-2 text-xs font-semibold text-emerald-800 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('agenda')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'agenda' 
              ? 'bg-purple-700 text-white shadow-xs' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <CalendarPlus className="w-4 h-4" />
          <span>Agenda y Avisos ({agenda.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('proyectos')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'proyectos' 
              ? 'bg-purple-700 text-white shadow-xs' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Proyectos del Centro ({projects.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('buzon')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'buzon' 
              ? 'bg-purple-700 text-white shadow-xs' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Inbox className="w-4 h-4" />
          <span>Buzón Privado ({tickets.length})</span>
        </button>
      </div>

      {/* TAB 1: AGENDA Y AVISOS */}
      {activeTab === 'agenda' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">
              Actividades y Torneos Publicados
            </h2>
            {!showNewEventForm && (
              <button
                onClick={() => {
                  resetEventForm();
                  setShowNewEventForm(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Publicar Nueva Actividad / Torneo</span>
              </button>
            )}
          </div>

          {/* Form Modal / Drawer */}
          {showNewEventForm && (
            <form onSubmit={handleSaveEvent} className="bg-white p-5 sm:p-6 rounded-3xl border border-purple-200 shadow-md space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold uppercase text-purple-900">
                  {editingEventId ? 'Editar Actividad Existente' : 'Nueva Publicación para Inicio y Agenda'}
                </span>
                <button
                  type="button"
                  onClick={resetEventForm}
                  className="p-1 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="space-y-1 sm:col-span-2">
                  <label className="block font-semibold text-slate-700">Título de la actividad / torneo:</label>
                  <input
                    type="text"
                    placeholder="Ej: Torneo Relámpago de Básquet Mixto"
                    value={eventTitle}
                    onChange={(e) => setEventTitle(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-semibold text-slate-700">Categoría:</label>
                  <select
                    value={eventCategory}
                    onChange={(e) => {
                      const cat = e.target.value as any;
                      setEventCategory(cat);
                      if (cat === 'torneo') setEventCategoryLabel('Torneo Deportivo');
                      else if (cat === 'radio') setEventCategoryLabel('Radio & Recreos');
                      else if (cat === 'asamblea') setEventCategoryLabel('Asamblea');
                      else setEventCategoryLabel('Audiovisual & Talleres');
                    }}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                  >
                    <option value="torneo">Torneo Deportivo</option>
                    <option value="radio">Radio & Recreos</option>
                    <option value="asamblea">Asamblea</option>
                    <option value="cultural">Audiovisual & Cortos</option>
                    <option value="taller">Taller / Formación</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block font-semibold text-slate-700">Lugar exacto:</label>
                  <input
                    type="text"
                    placeholder="Ej: Playón Deportivo y Gimnasio"
                    value={eventLocation}
                    onChange={(e) => setEventLocation(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-semibold text-slate-700">Día a mostrar:</label>
                  <input
                    type="text"
                    placeholder="Ej: Jueves 21 Nov"
                    value={eventDisplayDate}
                    onChange={(e) => setEventDisplayDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-semibold text-slate-700">Horario:</label>
                  <input
                    type="text"
                    placeholder="Ej: 13:30 a 16:30 hs"
                    value={eventTime}
                    onChange={(e) => setEventTime(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-semibold text-slate-700">Cursos destinatarios (separados por coma):</label>
                  <input
                    type="text"
                    placeholder="Ej: 3°, 4°, 5° o Todos"
                    value={eventYears}
                    onChange={(e) => setEventYears(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-semibold text-slate-700">Responsable / Comisión:</label>
                  <input
                    type="text"
                    placeholder="Ej: Secretaría de Deportes JL"
                    value={eventResponsible}
                    onChange={(e) => setEventResponsible(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1 sm:col-span-2">
                  <label className="block font-semibold text-slate-700">Descripción detallada y requisitos:</label>
                  <textarea
                    rows={3}
                    placeholder="Explicá las reglas, cupos y cómo participar..."
                    value={eventDesc}
                    onChange={(e) => setEventDesc(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-purple-600 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={eventConfirmed}
                    onChange={(e) => setEventConfirmed(e.target.checked)}
                    className="rounded text-purple-700 focus:ring-purple-600"
                  />
                  <span>Actividad confirmada (desmarcar si es tentativa)</span>
                </label>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={resetEventForm}
                    className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
                  >
                    Guardar y Publicar
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* List of Published Events */}
          <div className="space-y-3">
            {agenda.map((ev) => (
              <div
                key={ev.id}
                className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-purple-700">{ev.categoryLabel}</span>
                    <span>·</span>
                    <span className="text-slate-500">{ev.displayDate} ({ev.time})</span>
                    <span>·</span>
                    <span className="font-semibold text-slate-700">{ev.location}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900">{ev.title}</h4>
                  <span className="text-slate-500 text-[11px]">
                    Destinado a: {ev.years.join(', ')} · Responsable: {ev.responsible}
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <button
                    onClick={() => startEditEvent(ev)}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-purple-50 hover:text-purple-700 text-slate-700 rounded-lg font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Editar</span>
                  </button>
                  <button
                    onClick={() => onDeleteEvent(ev.id)}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                    title="Eliminar publicación"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: PROYECTOS DEL CENTRO */}
      {activeTab === 'proyectos' && (
        <div className="space-y-4">
          <h2 className="text-base font-bold text-slate-900">
            Actualizar Estado de los 10 Proyectos
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {projects.map((proj) => (
              <div
                key={proj.id}
                className="bg-white p-4 rounded-2xl border border-slate-200 space-y-3 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-purple-700">{proj.number}. {proj.name}</span>
                  <span className="text-[11px] font-semibold text-slate-500">{proj.progressPercent}%</span>
                </div>

                <p className="text-slate-600 line-clamp-2">
                  <strong>Próximo paso:</strong> {proj.nextStep}
                </p>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <span className="text-[11px] text-slate-400">
                    {proj.openCall ? 'Convocatoria abierta' : 'Sin convocatoria activa'}
                  </span>
                  <button
                    onClick={() => setEditingProject(proj)}
                    className="px-3 py-1 bg-purple-50 text-purple-700 hover:bg-purple-100 rounded-lg font-bold"
                  >
                    Editar avance
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Project Edit Modal */}
          {editingProject && (
            <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-2xs flex items-center justify-center p-4">
              <form 
                onSubmit={handleSaveProject}
                className="bg-white p-6 rounded-3xl max-w-md w-full space-y-4 text-left border border-slate-200"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="font-bold text-slate-900 text-sm">
                    Actualizar: {editingProject.name}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setEditingProject(null)}
                    className="p-1 text-slate-400"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Porcentaje de avance ({editingProject.progressPercent}%):
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={editingProject.progressPercent}
                      onChange={(e) => setEditingProject({
                        ...editingProject,
                        progressPercent: Number(e.target.value)
                      })}
                      className="w-full accent-purple-700"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      ¿Qué se está haciendo hoy?
                    </label>
                    <textarea
                      rows={2}
                      value={editingProject.currentWork}
                      onChange={(e) => setEditingProject({
                        ...editingProject,
                        currentWork: e.target.value
                      })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      Próximo paso:
                    </label>
                    <input
                      type="text"
                      value={editingProject.nextStep}
                      onChange={(e) => setEditingProject({
                        ...editingProject,
                        nextStep: e.target.value
                      })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700">
                      <input
                        type="checkbox"
                        checked={editingProject.openCall}
                        onChange={(e) => setEditingProject({
                          ...editingProject,
                          openCall: e.target.checked
                        })}
                        className="rounded text-purple-700"
                      />
                      <span>Abrir convocatoria estudiantil</span>
                    </label>
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setEditingProject(null)}
                    className="px-3 py-2 text-xs font-semibold text-slate-600"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold"
                  >
                    Guardar Cambios
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BUZÓN PRIVADO DE SUGERENCIAS */}
      {activeTab === 'buzon' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Bandeja de Mensajes de Estudiantes
              </h2>
              <p className="text-xs text-slate-500">
                Los mensajes recibidos son tratados por el cuerpo de delegados en la reunión semanal de los viernes.
              </p>
            </div>
            <span className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1 rounded-lg">
              {tickets.length} recibidos
            </span>
          </div>

          <div className="space-y-3">
            {tickets.map((tk) => (
              <div
                key={tk.id}
                className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3 text-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-purple-950 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                      {tk.code}
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-500 font-medium">Recibido: {tk.createdAt}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-600 font-semibold">
                      {tk.isAnonymous ? 'Anónimo' : `${tk.studentName} (${tk.studentCourse})`}
                    </span>
                  </div>

                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                    tk.status === 'en_asamblea'
                      ? 'bg-purple-100 text-purple-800'
                      : tk.status === 'derivado_direccion'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {tk.status === 'en_asamblea' ? 'Tratado en Asamblea' : tk.status === 'derivado_direccion' ? 'Derivado a Dirección' : 'Pendiente de revisión'}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 text-sm mb-1">{tk.topic}</h4>
                  <p className="text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                    "{tk.message}"
                  </p>
                </div>

                {tk.moderatorNotes && (
                  <div className="text-[11px] text-purple-900 bg-purple-50/70 p-2 rounded-lg border border-purple-100">
                    <strong>Nota interna:</strong> {tk.moderatorNotes}
                  </div>
                )}

                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-400">
                    Cambiar estado de tratamiento:
                  </span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => onUpdateTicketStatus(tk.id, 'en_asamblea', 'Agendado para lectura en la asamblea de delegados')}
                      className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-800 rounded font-semibold text-[11px]"
                    >
                      A Asamblea
                    </button>
                    <button
                      onClick={() => onUpdateTicketStatus(tk.id, 'derivado_direccion', 'Presentado formalmente ante el equipo directivo')}
                      className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded font-semibold text-[11px]"
                    >
                      A Dirección
                    </button>
                    <button
                      onClick={() => onUpdateTicketStatus(tk.id, 'pendiente', '')}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-[11px]"
                    >
                      Marcar Pendiente
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.div>
  );
};
