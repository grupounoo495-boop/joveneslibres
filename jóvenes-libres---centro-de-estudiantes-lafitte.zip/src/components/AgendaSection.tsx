import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  Filter, 
  RotateCcw, 
  ChevronRight, 
  X, 
  CalendarPlus, 
  Check, 
  Trophy,
  Users,
  AlertCircle
} from 'lucide-react';
import { AgendaEvent } from '../data/portalData';

interface AgendaSectionProps {
  agenda: AgendaEvent[];
  selectedItem: AgendaEvent | null;
  onSelectItem: (item: AgendaEvent | null) => void;
  initialCourse?: string;
}

export const AgendaSection: React.FC<AgendaSectionProps> = ({
  agenda,
  selectedItem,
  onSelectItem,
  initialCourse = 'Todos'
}) => {
  const [selectedYear, setSelectedYear] = useState<string>(initialCourse);
  const [selectedDivision, setSelectedDivision] = useState<string>('Todas');
  const [selectedCategory, setSelectedCategory] = useState<string>('todas');
  const [calendarDownloadedId, setCalendarDownloadedId] = useState<string | null>(null);

  const years = ['Todos', '1°', '2°', '3°', '4°', '5°', '6°'];
  const divisions = ['Todas', 'A', 'B', 'C'];
  const categories = [
    { id: 'todas', label: 'Todas las actividades' },
    { id: 'torneo', label: 'Torneos Deportivos' },
    { id: 'radio', label: 'Radio & Recreos' },
    { id: 'asamblea', label: 'Asambleas' },
    { id: 'cultural', label: 'Audiovisual & Talleres' }
  ];

  const isFiltered = selectedYear !== 'Todos' || selectedDivision !== 'Todas' || selectedCategory !== 'todas';

  const resetFilters = () => {
    setSelectedYear('Todos');
    setSelectedDivision('Todas');
    setSelectedCategory('todas');
  };

  const filteredItems = agenda.filter((item) => {
    const matchesYear = 
      selectedYear === 'Todos' || 
      item.years.includes(selectedYear) || 
      item.years.includes('Todos');
    
    const matchesDivision = 
      selectedDivision === 'Todas' || 
      item.divisions.includes(selectedDivision) || 
      item.divisions.includes('Todas');
    
    const matchesCategory = 
      selectedCategory === 'todas' || 
      item.category === selectedCategory;

    return matchesYear && matchesDivision && matchesCategory;
  });

  const handleDownloadCalendar = (item: AgendaEvent) => {
    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Jovenes Libres//Agenda Escolar//ES
BEGIN:VEVENT
SUMMARY:${item.title} - Lafitte
DESCRIPTION:${item.description}
LOCATION:${item.location}
STATUS:${item.isConfirmed ? 'CONFIRMED' : 'TENTATIVE'}
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `${item.title.replace(/[\s/]/g, '_')}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setCalendarDownloadedId(item.id);
    setTimeout(() => setCalendarDownloadedId(null), 3000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6 text-left"
    >
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Agenda Escolar y Torneos
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Encontrá qué torneos, asambleas y actividades hay para tu división en el Lafitte.
          </p>
        </div>

        {isFiltered && (
          <button
            onClick={resetFilters}
            className="self-start sm:self-center flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors border border-purple-200"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restablecer filtros</span>
          </button>
        )}
      </div>

      {/* Filter Bar with interactive segmented controls */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-700 pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-purple-600" />
            <span>Filtrar por tu año y división</span>
          </div>
          <span className="text-slate-500 font-normal">
            {filteredItems.length} {filteredItems.length === 1 ? 'actividad' : 'actividades'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          {/* Year selector */}
          <div className="md:col-span-5 space-y-1.5">
            <label className="block text-xs font-medium text-slate-600">
              Año escolar:
            </label>
            <div className="flex flex-wrap gap-1.5">
              {years.map((y) => (
                <button
                  key={y}
                  onClick={() => setSelectedYear(y)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                    selectedYear === y
                      ? 'bg-purple-700 text-white shadow-xs font-semibold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {y}
                </button>
              ))}
            </div>
          </div>

          {/* Division selector */}
          <div className="md:col-span-3 space-y-1.5">
            <label className="block text-xs font-medium text-slate-600">
              División:
            </label>
            <div className="flex gap-1.5">
              {divisions.map((d) => (
                <button
                  key={d}
                  onClick={() => setSelectedDivision(d)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                    selectedDivision === d
                      ? 'bg-purple-700 text-white shadow-xs font-semibold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          {/* Category selector */}
          <div className="md:col-span-4 space-y-1.5">
            <label className="block text-xs font-medium text-slate-600">
              Tipo de actividad:
            </label>
            <div className="flex flex-wrap gap-1.5">
              {categories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedCategory(c.id)}
                  className={`px-2.5 py-1.5 text-xs font-medium rounded-lg transition-all ${
                    selectedCategory === c.id
                      ? 'bg-purple-700 text-white shadow-xs font-semibold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Active Filter Chips */}
        {isFiltered && (
          <div className="flex flex-wrap items-center gap-2 pt-2 text-xs text-slate-500 border-t border-slate-100">
            <span>Filtros activos:</span>
            {selectedYear !== 'Todos' && (
              <span className="font-semibold text-purple-900 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                Año: {selectedYear}
              </span>
            )}
            {selectedDivision !== 'Todas' && (
              <span className="font-semibold text-purple-900 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                División: {selectedDivision}
              </span>
            )}
            {selectedCategory !== 'todas' && (
              <span className="font-semibold text-purple-900 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                Categoría: {categories.find(c => c.id === selectedCategory)?.label}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Events List */}
      {filteredItems.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-8 text-center space-y-3">
          <CalendarIcon className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">
            No hay actividades con estos filtros
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Probá seleccionando "Todos" los años o revisá las fechas generales del colegio.
          </p>
          <button
            onClick={resetFilters}
            className="px-4 py-2 bg-purple-700 text-white rounded-xl text-xs font-semibold hover:bg-purple-800 transition-colors inline-block"
          >
            Ver toda la agenda
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredItems.map((item) => (
            <motion.div
              key={item.id}
              whileHover={{ y: -2 }}
              onClick={() => onSelectItem(item)}
              className="bg-white rounded-2xl border border-slate-200 p-5 hover:border-purple-300 hover:shadow-md transition-all text-left flex flex-col justify-between cursor-pointer group"
            >
              <div>
                <div className="flex items-center justify-between gap-2 text-xs mb-2">
                  <div className="flex items-center gap-1.5">
                    {item.category === 'torneo' && <Trophy className="w-3.5 h-3.5 text-purple-700" />}
                    <span className="font-bold text-purple-700">{item.categoryLabel}</span>
                  </div>
                  <span className="text-[11px] font-medium text-slate-500">
                    Cursos: {item.years.join(', ')} (Div. {item.divisions.join(', ')})
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 group-hover:text-purple-700 transition-colors mb-2 leading-snug">
                  {item.title}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-2 mb-4 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-slate-900">
                    <CalendarIcon className="w-3.5 h-3.5 text-purple-600" />
                    <span>{item.displayDate}</span>
                    <span className="text-slate-400 font-normal">·</span>
                    <span className="font-normal text-slate-600">{item.time}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-600 font-semibold">
                    <MapPin className="w-3.5 h-3.5 text-purple-600" />
                    <span className="text-purple-950 truncate max-w-[200px]">{item.location}</span>
                  </div>
                </div>

                <span className="text-purple-700 font-semibold group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                  <span>Detalle</span>
                  <ChevronRight className="w-4 h-4" />
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Detail Modal (Preserves filter state upon closing!) */}
      <AnimatePresence>
        {selectedItem && (
          <div 
            className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-2xs flex items-center justify-center p-4 sm:p-6"
            onClick={() => onSelectItem(null)}
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.2 }}
              className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-5 text-left border border-slate-100 relative"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={() => onSelectItem(null)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
                aria-label="Cerrar detalle"
              >
                <X className="w-5 h-5" />
              </button>

              <div>
                <div className="flex items-center gap-2 text-xs text-purple-800 font-bold mb-1">
                  <span>{selectedItem.categoryLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span className={selectedItem.isConfirmed ? 'text-emerald-700' : 'text-amber-700'}>
                    {selectedItem.isConfirmed ? 'Confirmado' : 'Fecha pendiente de confirmación'}
                  </span>
                </div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight pr-8">
                  {selectedItem.title}
                </h2>
              </div>

              {/* Exact Location & Time Card */}
              <div className="bg-purple-50/80 rounded-2xl p-4 grid grid-cols-2 gap-3 text-xs border border-purple-100">
                <div>
                  <span className="block text-slate-500 mb-0.5">Día y horario:</span>
                  <span className="font-bold text-slate-900 flex items-center gap-1">
                    <CalendarIcon className="w-3.5 h-3.5 text-purple-600" />
                    {selectedItem.displayDate} ({selectedItem.time})
                  </span>
                </div>
                <div>
                  <span className="block text-slate-500 mb-0.5">Lugar exacto:</span>
                  <span className="font-bold text-purple-950 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-purple-600" />
                    {selectedItem.location}
                  </span>
                </div>
                <div>
                  <span className="block text-slate-500 mb-0.5">Años convocados:</span>
                  <span className="font-semibold text-slate-800">
                    {selectedItem.years.join(', ')}
                  </span>
                </div>
                <div>
                  <span className="block text-slate-500 mb-0.5">Divisiones:</span>
                  <span className="font-semibold text-slate-800">
                    {selectedItem.divisions.join(', ')}
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Detalles y requisitos para participar
                </h4>
                <p className="text-sm text-slate-700 leading-relaxed">
                  {selectedItem.description}
                </p>
                <div className="text-[11px] text-slate-400 pt-1">
                  Responsable: {selectedItem.responsible} · Actualizado el {selectedItem.updatedAt}
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row gap-2.5">
                <button
                  onClick={() => handleDownloadCalendar(selectedItem)}
                  className="flex-1 py-2.5 px-4 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  {calendarDownloadedId === selectedItem.id ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-300" />
                      <span>¡Guardado en calendario!</span>
                    </>
                  ) : (
                    <>
                      <CalendarPlus className="w-4 h-4" />
                      <span>Agregar a mi calendario (.ics)</span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => onSelectItem(null)}
                  className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Volver a la agenda
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};
